﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;

namespace JpmmsClasses.BL.Removed
{
    public class BillOfQuantities
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();


        public DataTable GetBillOfQuantitiesReport()
        {
            string sql = "SELECT * FROM item_info  ORDER BY project_no, Item_no ";
            return db.ExecuteQuery(sql);
        }


    }
}
