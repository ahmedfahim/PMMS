﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;

namespace JpmmsClasses.BL.Removed
{
    public class MaintDecisionPricing
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();



        public bool InsertMaintDecisionMaterial(int MAINT_DECISION_ID, int MATERIAL_ID, int UNIT_ID, decimal QUANTITY, decimal RATE)
        {
            //                                                                        0             1            2      3         4
            string sql = string.Format("insert into MAINT_PRICING(RECORD_ID, MAINT_DECISION_ID, MATERIAL_ID, UNIT_ID, QUANTITY, RATE) values(SEQ_PRICING.nextval, {0}, {1}, {2}, {3}, {4}) ",
               MAINT_DECISION_ID, MATERIAL_ID, UNIT_ID, QUANTITY, RATE);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool InsertMaintDecisionOperation(int MAINT_DECISION_ID, int OPERATION_ID, int UNIT_ID, decimal QUANTITY, decimal RATE)
        {
            //                                                                        0             1            2      3         4
            string sql = string.Format("insert into MAINT_PRICING(RECORD_ID, MAINT_DECISION_ID, OPERATION_ID, UNIT_ID, QUANTITY, RATE) values(SEQ_PRICING.nextval, {0}, {1}, {2}, {3}, {4}) ",
               MAINT_DECISION_ID, OPERATION_ID, UNIT_ID, QUANTITY, RATE);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool UpdateQtyRate(int RECORD_ID, int UNIT_ID, decimal QUANTITY, decimal RATE)
        {
            string sql = string.Format("update MAINT_PRICING set UNIT_ID={0}, QUANTITY={1}, RATE={2} where RECORD_ID={3} ", UNIT_ID, QUANTITY, RATE, RECORD_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Delete(int RECORD_ID)
        {
            string sql = string.Format("delete from MAINT_PRICING where RECORD_ID={0} ", RECORD_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }


        public DataTable GetForMaintenanceDecision(int MAINT_DECISION_ID)
        {
            if (MAINT_DECISION_ID == 0)
                return new DataTable();

            string sql1 = string.Format("select RECORD_ID, MAINT_DECISION_ID, MATERIAL_ID, MATERIAL_NAME, '' as OPERATION_NAME, OPERATION_ID, UNIT_ID, unit_name, QUANTITY, RATE, TOTAL_PRICE from VW_MAINT_DECISION_MATERIALS where MAINT_DECISION_ID={0} ", MAINT_DECISION_ID);
            string sql2 = string.Format("select RECORD_ID, MAINT_DECISION_ID, MATERIAL_ID, '' as MATERIAL_NAME, OPERATION_NAME, OPERATION_ID, UNIT_ID, unit_name, QUANTITY, RATE, TOTAL_PRICE from VW_MAINT_DECISION_OPERATIONS where MAINT_DECISION_ID={0} order by RECORD_ID ", MAINT_DECISION_ID);

            string sql = string.Format("{0} union {1} ", sql1, sql2);
            return db.ExecuteQuery(sql);
        }


        public static decimal GetMaintenanceTotalCost(int MAINT_DECISION_ID)
        {
            if (MAINT_DECISION_ID == 0)
                return 0;

            decimal cost = 0;
            OracleDatabaseClass db = new OracleDatabaseClass();

            string sql = string.Format("select nvl(sum(TOTAL_PRICE), 0) as TOTAL_PRICE from VW_MAINT_DECISION_MATERIALS where MAINT_DECISION_ID={0} ", MAINT_DECISION_ID);
            DataTable dt = db.ExecuteQuery(sql);
            cost = (dt.Rows.Count == 0) ? 0 : decimal.Parse(dt.Rows[0]["TOTAL_PRICE"].ToString());


            sql = string.Format("select nvl(sum(TOTAL_PRICE), 0) as TOTAL_PRICE from VW_MAINT_DECISION_OPERATIONS where MAINT_DECISION_ID={0} ", MAINT_DECISION_ID);
            dt = db.ExecuteQuery(sql);
            cost += (dt.Rows.Count == 0) ? 0 : decimal.Parse(dt.Rows[0]["TOTAL_PRICE"].ToString());

            return cost;
        }


    }
}
