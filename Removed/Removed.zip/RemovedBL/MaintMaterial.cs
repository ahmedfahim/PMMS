﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;

namespace JpmmsClasses.BL.Removed
{
    public class MaintMaterial
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();


        public bool Insert(string MATERIAL_NAME, int MATERIAL_UNIT_ID, decimal MATERIAL_PRICE)
        {
            MATERIAL_NAME = MATERIAL_NAME.Replace("'", "''");
            string sql = string.Format("insert into MAINT_MATERIALS(MATERIAL_ID, MATERIAL_NAME, MATERIAL_UNIT_ID, MATERIAL_PRICE) values(SEQ_MATERIALS.nextval, '{0}', {1}, {2}) ", MATERIAL_NAME, MATERIAL_UNIT_ID, MATERIAL_PRICE);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Update(string MATERIAL_NAME, int MATERIAL_UNIT_ID, decimal MATERIAL_PRICE, int MATERIAL_ID)
        {
            MATERIAL_NAME = MATERIAL_NAME.Replace("'", "''");
            string sql = string.Format("update MAINT_MATERIALS set MATERIAL_NAME='{0}', MATERIAL_UNIT_ID={1}, MATERIAL_PRICE={2} where MATERIAL_ID={3} ", MATERIAL_NAME, MATERIAL_UNIT_ID, MATERIAL_PRICE, MATERIAL_ID);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Delete(int MATERIAL_ID)
        {
            string sql = string.Format("delete from MAINT_MATERIALS where MATERIAL_ID={0} ", MATERIAL_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public DataTable GetAll()
        {
            string sql = "select MATERIAL_ID, MATERIAL_NAME, MATERIAL_UNIT_ID, unit_name, MATERIAL_PRICE from vw_materials_full order by MATERIAL_NAME ";
            return db.ExecuteQuery(sql);
        }

        public DataTable GetByID(int MATERIAL_ID)
        {
            string sql = string.Format("select MATERIAL_ID, MATERIAL_NAME, MATERIAL_UNIT_ID, unit_name, MATERIAL_PRICE from vw_materials_full where MATERIAL_ID={0} order by MATERIAL_NAME ", MATERIAL_ID);
            return db.ExecuteQuery(sql);
        }

    }
}
