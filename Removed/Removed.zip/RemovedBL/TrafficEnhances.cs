﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;
using System.Windows.Forms;

namespace JpmmsClasses.BL.Removed
{
    public class TrafficEnhances
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();



        public DataTable GetAll()
        {
            //string sql = "SELECT TRAFFIC_ENHANCES.TRAFF_ENHANC_ID, TRAFFIC_ENHANCES.CONTRACT_NO, TRAFFIC_ENHANCES.CONTRACT_NAME, TRAFFIC_ENHANCES.CONTRACTOR_ID, TRAFFIC_ENHANCES.CONTRACT_DATE, TRAFFIC_ENHANCES.CONTRACT_BEGIN, TRAFFIC_ENHANCES.CONTRACT_END, CONTRACTOR.CONTRACTOR_NAME FROM TRAFFIC_ENHANCES, CONTRACTOR WHERE TRAFFIC_ENHANCES.CONTRACTOR_ID = CONTRACTOR.CONTRACTOR_No ORDER BY TRAFFIC_ENHANCES.CONTRACT_DATE DESC ";
            string sql = "select RECORD_ID, DETAILS, CONTRACT_NO, CONTRACT_NAME, CONTRACTOR_ID, CONTRACT_DATE, CONTRACT_BEGIN, CONTRACT_END, CONTRACTOR_NAME from VW_TRAFFIC_ENHANCES_FULL order by DETAILS ";
            return db.ExecuteQuery(sql);
        }

        public bool Insert(string Details, bool isContract, string CONTRACT_NO, string CONTRACT_NAME, int CONTRACTOR_ID, DateTime? CONTRACT_DATE, DateTime? CONTRACT_BEGIN,
            DateTime? CONTRACT_END)
        {
            CONTRACT_NO = CONTRACT_NO.Replace("'", "''");
            CONTRACT_NAME = CONTRACT_NAME.Replace("'", "''");
            Details = Details.Replace("'", "''");

            string contractorIDPart = (CONTRACTOR_ID == 0) ? "NULL" : CONTRACTOR_ID.ToString();

            string contractDatePart = (CONTRACT_DATE == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_DATE).ToString("dd/MM/yyyy"));
            string contractBeginPart = (CONTRACT_BEGIN == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_BEGIN).ToString("dd/MM/yyyy"));
            string contractEndPart = (CONTRACT_END == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_END).ToString("dd/MM/yyyy"));

            //                                                                      0          1            2           3           4               5               6               7
            string sql = string.Format("INSERT INTO TRAFF_ENHANC_DETAILS(RECORD_ID, DETAILS, IS_CONTRACT, CONTRACT_NO, CONTRACT_NAME, CONTRACTOR_ID, CONTRACT_DATE, CONTRACT_BEGIN, CONTRACT_END) " +
                " VALUES (SEQ_TRAFFIC_ENHANCES.nextval, '{0}', {1}, '{2}', '{3}', {4}, {5}, {6}, {7}) ",
                Details, Shared.Bool2Int(isContract), CONTRACT_NO, CONTRACT_NAME, contractorIDPart, contractDatePart, contractBeginPart, contractEndPart);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Update(string Details, string CONTRACT_NO, string CONTRACT_NAME, int CONTRACTOR_ID, DateTime? CONTRACT_DATE, DateTime? CONTRACT_BEGIN, DateTime? CONTRACT_END, int TRAFF_ENHANC_ID)
        {
            // string CONTRACT_DATE, string CONTRACT_BEGIN, string CONTRACT_END, 
            CONTRACT_NO = CONTRACT_NO.Replace("'", "''");
            CONTRACT_NAME = CONTRACT_NAME.Replace("'", "''");
            Details = Details.Replace("'", "''");

            string contractorIDPart = (CONTRACTOR_ID == 0) ? "NULL" : CONTRACTOR_ID.ToString();

            string contractDatePart = (CONTRACT_DATE == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_DATE).ToString("dd/MM/yyyy"));
            string contractBeginPart = (CONTRACT_BEGIN == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_BEGIN).ToString("dd/MM/yyyy"));
            string contractEndPart = (CONTRACT_END == null) ? "NULL" : string.Format("'{0}'", ((DateTime)CONTRACT_END).ToString("dd/MM/yyyy"));

            bool isContract = !string.IsNullOrEmpty(CONTRACT_NO) || !string.IsNullOrEmpty(CONTRACT_NAME);

            //CONTRACT_DATE = string.IsNullOrEmpty(CONTRACT_DATE) ? "NULL" : string.Format("'{0}'", Shared.FormatDateArEgDMY(CONTRACT_DATE));
            //CONTRACT_BEGIN = string.IsNullOrEmpty(CONTRACT_BEGIN) ? "NULL" : string.Format("'{0}'", Shared.FormatDateArEgDMY(CONTRACT_BEGIN));
            //CONTRACT_END = string.IsNullOrEmpty(CONTRACT_END) ? "NULL" : string.Format("'{0}'", Shared.FormatDateArEgDMY(CONTRACT_END));

            string sql = string.Format("UPDATE TRAFF_ENHANC_DETAILS SET CONTRACT_NO='{0}', CONTRACT_NAME='{1}', CONTRACTOR_ID={2}, CONTRACT_DATE={3}, CONTRACT_BEGIN={4}, CONTRACT_END={5}, DETAILS='{7}', IS_CONTRACT={8} WHERE RECORD_ID={6} ",
                CONTRACT_NO, CONTRACT_NAME, contractorIDPart, contractDatePart, contractBeginPart, contractEndPart, TRAFF_ENHANC_ID, Details, Shared.Bool2Int(isContract));

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Delete(int RECORD_ID)
        {
            if (RECORD_ID == 0)
                return false;

            int rows = 0;
            DeleteDetailForTrafficEnhance(RECORD_ID);

            string sql = string.Format("delete from TRAFF_ENHANC_DETAILS WHERE RECORD_ID={0} ", RECORD_ID);
            rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }
        

        private bool DeleteDetailForTrafficEnhance(int TRAFFENHANCE_DET_ID)
        {
            string sql = string.Format("delete from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={0} ", TRAFFENHANCE_DET_ID);
            //in (select RECORD_ID from  TRAFF_ENHANC_DETAILS where TRAFF_ENHANCE_ID={0}) ", TRAFF_ENHANC_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }


        public bool AddTrafficEnhanceDetailLocations(int TrafficEnhanceDetailID, bool section, bool intersect, bool region, int mainID, int subID, bool district,
            bool munic, string title)
        {
            int rows = 0;
            string sql = "";
            string lang = HttpContext.Current.Session["lang"].ToString();

            if (section)
            {
                if (subID != 0)
                {
                    sql = string.Format("select record_id from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={0} and SECTION_ID={1} and IS_SECTION=1 ", TrafficEnhanceDetailID, subID);
                    if (db.ExecuteQuery(sql).Rows.Count > 0)
                        throw new Exception(Feedback.InsertExceptionUnique(lang));

                    //                                                                              0                   1           2         
                    sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, MAIN_ST_ID, SECTION_ID, IS_SECTION) " +
                        " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, subID);

                    rows = db.ExecuteNonQuery(sql);
                }
                else
                {
                    //DialogResult r = MessageBox.Show("هل تريد فعلا إضافة كل مقاطع هذا الطريق؟", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    //if (r == DialogResult.Yes)
                    //{
                    sql = string.Format("select section_id from sections where MAIN_STREET_ID={0} and section_id not in (select section_id from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={1} and section_id is not null)  ", mainID, TrafficEnhanceDetailID);
                    DataTable dtSections = db.ExecuteQuery(sql);
                    foreach (DataRow dr in dtSections.Rows)
                    {
                        sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, MAIN_ST_ID, SECTION_ID, IS_SECTION) " +
                       " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, dr["section_id"].ToString());

                        rows += db.ExecuteNonQuery(sql);
                    }
                    //}
                }

                return (rows > 0);
            }
            else if (intersect)
            {
                if (subID != 0)
                {
                    sql = string.Format("select record_id from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={0} and INTERSECT_ID={1} and IS_INTERSECT=1 ", TrafficEnhanceDetailID, subID);
                    if (db.ExecuteQuery(sql).Rows.Count > 0)
                        throw new Exception(Feedback.InsertExceptionUnique(lang));

                    //                                                                              0                   1           2         
                    sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, MAIN_ST_ID, INTERSECT_ID, IS_INTERSECT) " +
                        " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, subID);

                    rows = db.ExecuteNonQuery(sql);
                }
                else
                {
                    //DialogResult r = MessageBox.Show("هل تريد فعلا إضافة كل تقاطعات هذا الطريق؟", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    //if (r == DialogResult.Yes)
                    //{
                    sql = string.Format("select INTERSECTION_ID from INTERSECTIONS where MAIN_STREET_ID={0} and INTERSECTION_ID not in (select INTERSECT_ID from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={1} and INTERSECT_ID is not null)   ", mainID, TrafficEnhanceDetailID);
                    DataTable dtIntersects = db.ExecuteQuery(sql);
                    foreach (DataRow dr in dtIntersects.Rows)
                    {
                        //                                                                              0                   1           2         
                        sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, MAIN_ST_ID, INTERSECT_ID, IS_INTERSECT) " +
                            " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, dr["INTERSECTION_ID"].ToString());

                        rows += db.ExecuteNonQuery(sql);
                    }
                    //}
                }

                return (rows > 0);
            }
            else if (region)
            {
                if (subID != 0)
                {
                    sql = string.Format("select record_id from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={0} and SECOND_ST_ID={1} and IS_REGION=1 ", TrafficEnhanceDetailID, subID);
                    if (db.ExecuteQuery(sql).Rows.Count > 0)
                        throw new Exception(Feedback.InsertExceptionUnique(lang));

                    //                                                                              0                   1           2         
                    sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, REGION_ID, SECOND_ST_ID, IS_REGION) " +
                        " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, subID);

                    rows = db.ExecuteNonQuery(sql);
                }
                else
                {
                    //DialogResult r = MessageBox.Show("هل تريد فعلا إضافة كل الشوارع الفرعية بهذه المنطقة؟", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    //if (r == DialogResult.Yes)
                    //{
                    sql = string.Format("select second_id from SECONDARY_STREETS where REGION_ID={0} and second_id not in (select SECOND_ST_ID from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={1} and SECOND_ST_ID is not null) ", mainID, TrafficEnhanceDetailID);
                    DataTable dtSecSt = db.ExecuteQuery(sql);
                    foreach (DataRow dr in dtSecSt.Rows)
                    {
                        //                                                                              0                   1           2         
                        sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, REGION_ID, SECOND_ST_ID, IS_REGION) " +
                            " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, mainID, dr["ID1"].ToString());

                        rows += db.ExecuteNonQuery(sql);
                    }
                    //}
                }

                return (rows > 0);
            }
            else if (district)
            {
                //DialogResult r = MessageBox.Show("هل تريد فعلا إضافة كل الشوارع الفرعية بمجموعة المناطق هذه؟", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                //if (r == DialogResult.Yes && !string.IsNullOrEmpty(title))
                //{
                sql = string.Format("select ID1, REGION_ID from GV_SEC_STREET where DIST_NAME='{0}' and second_id not in (select SECOND_ST_ID from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={1} and SECOND_ST_ID is not null) ", title, TrafficEnhanceDetailID);
                DataTable dtSecSt = db.ExecuteQuery(sql);
                foreach (DataRow dr in dtSecSt.Rows)
                {
                    //                                                                              0                   1           2         
                    sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, REGION_ID, SECOND_ST_ID, IS_REGION) " +
                        " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, dr["REGION_ID"].ToString(), dr["ID1"].ToString());

                    rows += db.ExecuteNonQuery(sql);
                }
                //}

                return (rows > 0);
            }
            else if (munic)
            {
                //DialogResult r = MessageBox.Show("هل تريد فعلا إضافة كل الشوارع الفرعية بهذه البلدية؟", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                //if (r == DialogResult.Yes && !string.IsNullOrEmpty(title))
                //{
                sql = string.Format("select second_id, REGION_ID from GV_SEC_STREET where MUNIC_NAME='{0}' and ID1 not in (select SECOND_ST_ID from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={1} and SECOND_ST_ID is not null) ", title, TrafficEnhanceDetailID);
                DataTable dtSecSt = db.ExecuteQuery(sql);
                foreach (DataRow dr in dtSecSt.Rows)
                {
                    //                                                                              0                   1           2         
                    sql = string.Format("insert into TRAFFENHANCE_DETAIL_LOCATIONS(RECORD_ID, TRAFFENHANCE_DET_ID, REGION_ID, SECOND_ST_ID, IS_REGION) " +
                        " values(SEQ_TRAFFENHANCE_LOC.nextval, {0}, {1}, {2}, 1) ", TrafficEnhanceDetailID, dr["REGION_ID"].ToString(), dr["ID1"].ToString());

                    rows += db.ExecuteNonQuery(sql);
                }
                //}

                return (rows > 0);
            }
            else
                return false;
        }



        public bool DeleteTrafficEnhanceDetailLocations(int RECORD_ID)
        {
            string sql = string.Format("delete from TRAFFENHANCE_DETAIL_LOCATIONS where RECORD_ID={0} ", RECORD_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        private bool DeleteTrafficEnhanceDetailLocationsByDetail(int TRAFFENHANCE_DET_ID)
        {
            string sql = string.Format("delete from TRAFFENHANCE_DETAIL_LOCATIONS where TRAFFENHANCE_DET_ID={0} ", TRAFFENHANCE_DET_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public DataTable GetTrafficEnhanceDetailLocations(int trafficEnhanceDetailID)
        {
            string sql = string.Format("select * from  VW_TRAFFIC_ENHANCE_LOCS where TRAFFENHANCE_DET_ID={0} ", trafficEnhanceDetailID);
            return db.ExecuteQuery(sql);
        }


        public DataTable Search(string detail, int contractorID, DateTime? from, DateTime? to, bool mainSt, int id, bool allRoads)
        {
            string sql = "select * from VW_TRAFFIC_ENHANCES_FULL ";
            bool firstArgs = true;

            if (!string.IsNullOrEmpty(detail))
            {
                if (firstArgs)
                {
                    sql = string.Format("{0} where DETAILS like '%{1}%' ", sql, detail.Replace("'", "''"));
                    firstArgs = false;
                }
                else
                    sql = string.Format("{0} and DETAILS like '%{1}%' ", sql, detail.Replace("'", "''"));
            }

            if (contractorID != 0)
            {
                if (firstArgs)
                {
                    sql = string.Format("{0} where CONTRACTOR_ID={1} ", sql, contractorID);
                    firstArgs = false;
                }
                else
                    sql = string.Format("{0} and CONTRACTOR_ID={1} ", sql, contractorID);
            }

            if (from != null && to != null)
            {
                if (firstArgs)
                {
                    sql = string.Format("{0} where CONTRACT_DATE between TO_DATE('{1}','DD/MM/YYYY') and TO_DATE('{2}','DD/MM/YYYY')) ", sql, ((DateTime)from).ToString("dd/MM/yyyy"),
                        ((DateTime)to).ToString("dd/MM/yyyy"));
                    firstArgs = false;
                }
                else
                    sql = string.Format("{0} and CONTRACT_DATE between TO_DATE('{1}','DD/MM/YYYY') and TO_DATE('{2}','DD/MM/YYYY')) ", sql, ((DateTime)from).ToString("dd/MM/yyyy"),
                        ((DateTime)to).ToString("dd/MM/yyyy"));
            }

            if (!allRoads && id != 0)
            {
                string colName = mainSt ? "MAIN_ST_ID" : "REGION_ID";
                if (firstArgs)
                {
                    sql = string.Format("{0} where {2}={1} ", sql, id, colName);
                    firstArgs = false;
                }
                else
                    sql = string.Format("{0} and {2}={1} ", sql, id, colName);
            }


            if (!string.IsNullOrEmpty(sql))
                return db.ExecuteQuery(sql);
            else
                return new DataTable();
        }


    }
}
