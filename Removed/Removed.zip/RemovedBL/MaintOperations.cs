﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;

namespace JpmmsClasses.BL.Removed
{
    public class MaintOperations
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();



        public bool Insert(string OPERATION_NAME, int OPERATION_UNIT_ID, decimal FIXED_PRICE)
        {
            OPERATION_NAME = OPERATION_NAME.Replace("'", "''");
            string sql = string.Format("insert into MAINT_OPERATIONS(OPERATION_ID, OPERATION_NAME, OPERATION_UNIT_ID, FIXED_PRICE) values(SEQ_OPERATIONS.nextval, '{0}', {1}, {2}) ", OPERATION_NAME, OPERATION_UNIT_ID, FIXED_PRICE);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Update(string OPERATION_NAME, int OPERATION_UNIT_ID, decimal FIXED_PRICE, int OPERATION_ID)
        {
            OPERATION_NAME = OPERATION_NAME.Replace("'", "''");
            string sql = string.Format("update MAINT_OPERATIONS set OPERATION_NAME='{0}', OPERATION_UNIT_ID={1}, FIXED_PRICE={2} where OPERATION_ID={3} ", OPERATION_NAME, OPERATION_UNIT_ID, FIXED_PRICE, OPERATION_ID);

            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public bool Delete(int OPERATION_ID)
        {
            string sql = string.Format("delete from MAINT_OPERATIONS where OPERATION_ID={0} ", OPERATION_ID);
            int rows = db.ExecuteNonQuery(sql);
            return (rows > 0);
        }

        public DataTable GetAll()
        {
            string sql = "select OPERATION_ID, OPERATION_NAME, OPERATION_UNIT_ID, unit_name, FIXED_PRICE from vw_operations_full order by OPERATION_NAME ";
            return db.ExecuteQuery(sql);
        }

        public DataTable GetByID(int OPERATION_ID)
        {
            string sql = string.Format("select OPERATION_ID, OPERATION_NAME, OPERATION_UNIT_ID, unit_name, FIXED_PRICE from vw_operations_full where OPERATION_ID={0} order by OPERATION_NAME ", OPERATION_ID);
            return db.ExecuteQuery(sql);
        }


    }
}
