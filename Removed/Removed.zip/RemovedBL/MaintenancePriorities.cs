﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;
using JpmmsClasses.BL;
//using Oracle.DataAccess.Client;
using System.Web;

namespace JpmmsClasses.BL
{
    public class MaintenancePriorities
    {
        private OracleDatabaseClass db = new OracleDatabaseClass();



        #region Regions

        public bool CalculateMaintenancePrioritiesRegions(int surveyNo, string user)
        {
            if (surveyNo == 0)
                return false;

            // section_no,  DIST_SEVERITY desc,
            int rows = 0;
            //string sql = string.Format("delete from MAINT_PRIORITY where region_no is not null and SURVEY_NO={0} ", surveyNo);
            //db.ExecuteNonQuery(sql);


            //double priority = 1.01;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //DataTable dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 1.02;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=60 and udi>40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.03;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.04;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.05;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=70 and udi>60 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.06;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=60 and udi>40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.07;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=60 and udi>40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.08;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=70 and udi>60 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.09;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=70 and udi>60 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.10;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=60 and udi>40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.11;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=100 and udi>90 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.12;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=90 and udi>70 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.13;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=90 and udi>70 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.14;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=100 and udi>90 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.15;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=100 and udi>90 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());



            //priority = 2.1;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=100 and udi>70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.2;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=100 and udi>70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.3;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=100 and udi>70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.4;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=3 and udi<=70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.5;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=2 and udi<=70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.6;
            //sql = string.Format("select * from VW_MAINT_DEC_REGIONS_UDI where complete_factor=1 and udi<=70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={0} order by pop_factor desc, maint_area asc ", surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertRegionMaintenancePriorityRecord(dr["REGION_NO"].ToString(), dr["SECOND_NO"].ToString(), int.Parse(dr["SECOND_ID"].ToString()),
            //        decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["POP_FACTOR"].ToString()),
            //        int.Parse(dr["COMPLETE_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //Shared.SaveLogfile("MAINT_PRIORITY", rows.ToString(), "Maintenance Decision Priorities - Main Street Regions", user);
            return (rows > 0);
        }

      

        private int InsertRegionMaintenancePriorityRecord(string regionNo, string secondNo, int SecondID, decimal udi, string udiDate, int surveyNo, int popuFactor,
         int completeFactor, string maintDecision, decimal maintArea, double priority, string surveyDate)
        {
            //                                                                  0           1           2       3       4           5      6           7                    8              9            10          11   
            string sql = string.Format("insert into MAINT_PRIORITY(RECORD_ID, REGION_NO, SECOND_NUM, SECOND_ID, UDI, UDI_DATE, SURVEY_NO, POP_FACTOR, COMPLETE_FACTOR, MAINT_DECISION, PRIORITY_NUM, MAINT_AREA, SURVEY_DATE) " +
                "values(SEQ_MAINT_PRIO.nextval, '{0}', '{1}', {2}, {3}, To_date('{4}','DD/MM/YYYY'), {5}, {6}, {7}, '{8}', {9}, {10}, To_date('{11}','DD/MM/YYYY')) ",
                regionNo, secondNo, SecondID, udi.ToString("N2"), Shared.FormatDateArEgDMY(udiDate), surveyNo, popuFactor, completeFactor, maintDecision,
                priority.ToString("N2"), maintArea, DateTime.Parse(surveyDate).ToString("dd/MM/yyyy"));

            return db.ExecuteNonQuery(sql);
        }

        #endregion


        #region MainStreetSections

        public bool CalculateMaintenancePrioritiesMainStreetSections(int mainStID, int surveyNo, string user)
        {
            if (mainStID == 0 || surveyNo == 0)
                return false;

            // section_no,  DIST_SEVERITY desc,
            int rows = 0;
            //string sql = string.Format("delete from MAINT_PRIORITY where MAIN_ST_ID={0} and SECTION_NO is not null and SURVEY_NO={1} ", mainStID, surveyNo);
            //db.ExecuteNonQuery(sql);


            //double priority = 1.1;

            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=39 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={1} order by geo_factor desc, traffic_factor desc, complete_factor desc, iri desc ", mainStID, surveyNo);
            //DataTable dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //         dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["LANE_ID"].ToString()), 
            //         dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()), int.Parse(dr["ENTRANCE"].ToString()), 
            //         int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //         dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 1.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=69 and udi>=40 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={1} order by geo_factor desc, traffic_factor desc, complete_factor desc, iri desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["LANE_ID"].ToString()), 
            //        dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()), int.Parse(dr["ENTRANCE"].ToString()), 
            //        int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 1.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi>=70 and RECOMMENDED_DECISION like '%Overlay%' and survey_no={1} order by  geo_factor desc, traffic_factor desc, complete_factor desc, iri desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["LANE_ID"].ToString()), 
            //        dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()), int.Parse(dr["ENTRANCE"].ToString()), 
            //        int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()), dr["RECOMMENDED_DECISION"].ToString(), 
            //        decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 2.1;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=100 and udi>=90 and RECOMMENDED_DECISION like '%Seal%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA,  iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["LANE_ID"].ToString()), 
            //        dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()), int.Parse(dr["ENTRANCE"].ToString()), 
            //        int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 2.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=89 and udi>=70 and RECOMMENDED_DECISION like '%Seal%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA,  iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()),
            //        int.Parse(dr["LANE_ID"].ToString()), dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()),
            //        int.Parse(dr["ENTRANCE"].ToString()), int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 2.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=69 and udi>=40 and RECOMMENDED_DECISION like '%Seal%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA,  iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()),
            //        int.Parse(dr["LANE_ID"].ToString()), dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()),
            //        int.Parse(dr["ENTRANCE"].ToString()), int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 3.1;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=100 and udi>=90 and RECOMMENDED_DECISION like '%Patching%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA, iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()),
            //        int.Parse(dr["LANE_ID"].ToString()), dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()),
            //        int.Parse(dr["ENTRANCE"].ToString()), int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 3.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=89 and udi>=70 and RECOMMENDED_DECISION like '%Patching%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA, iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()),
            //        int.Parse(dr["LANE_ID"].ToString()), dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()),
            //        int.Parse(dr["ENTRANCE"].ToString()), int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 3.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_LANES where main_street_id={0} and udi<=69 and udi>=40 and RECOMMENDED_DECISION like '%Patching%' and survey_no={1} order by  udi desc, geo_factor desc, traffic_factor desc, MAINT_AREA, iri desc, complete_factor desc ", mainStID, surveyNo);
            //dtResult = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtResult.Rows)
            //    rows += InsertSectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["SECTION_NO"].ToString(), dr["MAIN_STREET_ID"].ToString(),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()),
            //        int.Parse(dr["LANE_ID"].ToString()), dr["LANE_TYPE"].ToString(), int.Parse(dr["POP_FACTOR"].ToString()), int.Parse(dr["TOURISM_FACTOR"].ToString()),
            //        int.Parse(dr["ENTRANCE"].ToString()), int.Parse(dr["GEO_FACTOR"].ToString()), int.Parse(dr["COMPLETE_FACTOR"].ToString()), int.Parse(dr["TRAFFIC_FACTOR"].ToString()),
            //        dr["RECOMMENDED_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //// int.Parse(dr["PRV_MAINT_ID"].ToString()), true, int.Parse(dr["STRC_MAINT_ID"].ToString()), false
            //Shared.SaveLogfile("MAINT_PRIORITY", rows.ToString(), "Maintenance Decision Priorities - Main Street Sections:" + mainStID.ToString(), user);
            return (rows > 0);
        }

      

        private int InsertSectionMaintenancePriorityRecord(string mainNo, string mainName, string sectionNo, string mainStID, string iri, decimal udi, string udiDate,
         int surveyNo, int laneID, string laneType, int popuFactor, int tourismFactor, int entranceFactor, int geoFactor, int completeFactor, int trafficFactor,
         string maintDecision, decimal maintArea, double priority, string surveyDate)
        {
            //string preventiveOrStructivePart = structive ? "STRUCT_MAINT_ID" : "PRVNT_MAINT_ID"; //Shared.FormatDateArEgDMY( // DateTime.Parse().ToString("dd/MM/yyyy")
            // int structiveMaintID, , bool structive {20}, structiveMaintID, , preventiveOrStructivePart , {19} , .ToString("N2")

            iri = string.IsNullOrEmpty(iri) ? "''" : iri;
            //                                                                  0           1           2           3       4    5      6           7       8          9            10          11          12          13             14       15              16                  17          18          19
            string sql = string.Format("insert into MAINT_PRIORITY(RECORD_ID, MAIN_NO, MAIN_NAME, SECTION_NO, MAIN_ST_ID, IRI, UDI, UDI_DATE, SURVEY_NO, LANE_ID, LANE_TYPE, POP_FACTOR, TOURISM_FACTOR, ENTRANCE, GEO_FACTOR, COMPLETE_FACTOR, TRAFFIC_FACTOR, MAINT_DECISION, PRIORITY_NUM, MAINT_AREA, SURVEY_DATE) " +
                "values(SEQ_MAINT_PRIO.nextval, '{0}', '{1}', '{2}', {3}, {4}, {5}, To_date('{6}','DD/MM/YYYY'), {7}, {8}, '{9}', {10}, {11}, {12}, {13}, {14}, {15}, '{16}', '{17}', {18}, To_date('{19}','DD/MM/YYYY')) ",
                mainNo, mainName, sectionNo, mainStID, iri, udi.ToString("N2"), udiDate, surveyNo, laneID, laneType, popuFactor, tourismFactor, entranceFactor, geoFactor,
                completeFactor, trafficFactor, maintDecision, priority.ToString("N2"), maintArea, surveyDate);

            return db.ExecuteNonQuery(sql);
        }

        #endregion


        #region MainStreetIntersections

        public bool CalculateMaintenancePrioritiesMainStreetIntersections(int mainStID, int surveyNo, string user)
        {
            if (mainStID == 0 || surveyNo == 0)
                return false;

            // section_no,  DIST_SEVERITY desc,
            int rows = 0;
            //string sql = string.Format("delete from MAINT_PRIORITY where MAIN_ST_ID={0} and inter_no is not null and SURVEY_NO={1} ", mainStID, surveyNo);
            //db.ExecuteNonQuery(sql);


            //double priority = 1.1;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi<=39 and MAINT_DECISION like '%Overlay%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc ", mainStID, surveyNo);
            //DataTable dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi<=69 and udi>=40 and MAINT_DECISION like '%Overlay%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 1.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=70 and MAINT_DECISION like '%Overlay%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.1;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=90 and udi<=100 and MAINT_DECISION like '%Seal%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=70 and udi<=89 and MAINT_DECISION like '%Seal%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 2.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=40 and udi<=69 and MAINT_DECISION like '%Seal%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());


            //priority = 3.1;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=90 and udi<=100 and MAINT_DECISION like '%Patching%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 3.2;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=70 and udi<=89 and MAINT_DECISION like '%Patching%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //priority = 3.3;
            //sql = string.Format("select * from VW_MAINT_DEC_IRI_INTERSECT where main_street_id={0} and udi>=40 and udi<=69 and MAINT_DECISION like '%Patching%' and survey_no={1} order by street1_factor desc, street2_factor desc, udi asc, MAINT_AREA asc ", mainStID, surveyNo);
            //dtMaints = db.ExecuteQuery(sql);
            //foreach (DataRow dr in dtMaints.Rows)
            //    rows += InsertIntersectionMaintenancePriorityRecord(dr["MAIN_NO"].ToString(), dr["MAIN_NAME"].ToString(), dr["INTER_NO"].ToString(), int.Parse(dr["MAIN_STREET_ID"].ToString()),
            //        dr["IRI"].ToString(), decimal.Parse(dr["UDI"].ToString()), dr["UDI_DATE"].ToString(), int.Parse(dr["SURVEY_NO"].ToString()), int.Parse(dr["STREET1_FACTOR"].ToString()),
            //        int.Parse(dr["STREET2_FACTOR"].ToString()), dr["MAINT_DECISION"].ToString(), decimal.Parse(dr["MAINT_AREA"].ToString()), priority, dr["SURVEY_DATE"].ToString());

            //Shared.SaveLogfile("MAINT_PRIORITY", rows.ToString(), "Maintenance Decision Priorities - Main Street Intersections:" + mainStID.ToString(), user);
            return (rows > 0);
        }

      

        private int InsertIntersectionMaintenancePriorityRecord(string mainNo, string mainName, string interNo, int mainStID, string iri, decimal udi, string udiDate,
            int surveyNo, int street1Factor, int street2Factor, string maintDecision, decimal maintArea, double priority, string surveyDate)
        {
            //string preventiveOrStructivePart = structive ? "STRUCT_MAINT_ID" : "PRVNT_MAINT_ID"; //Shared.FormatDateArEgDMY( DateTime.Parse().ToString("dd/MM/yyyy")
            // int structiveMaintID, , bool structive {20}, structiveMaintID, , preventiveOrStructivePart , {19} , .ToString("N2")

            iri = string.IsNullOrEmpty(iri) ? "''" : iri;
            //                                                                  0           1           2           3    4    5      6           7       8                  9            10                 11          12          13
            string sql = string.Format("insert into MAINT_PRIORITY(RECORD_ID, MAIN_NO, MAIN_NAME, INTER_NO, MAIN_ST_ID, IRI, UDI, UDI_DATE, SURVEY_NO, STREET1_FACTOR, STREET2_FACTOR, MAINT_DECISION, PRIORITY_NUM, MAINT_AREA, SURVEY_DATE) " +
                "values(SEQ_MAINT_PRIO.nextval, '{0}', '{1}', '{2}', {3}, {4}, {5}, To_date('{6}','DD/MM/YYYY'), {7}, {8}, {9}, '{10}', {11}, {12}, To_date('{13}','DD/MM/YYYY')) ",
                mainNo, mainName, interNo, mainStID, iri, udi.ToString("N2"), udiDate, surveyNo, street1Factor, street2Factor, maintDecision, priority.ToString("N2"),
                maintArea, surveyDate);

            return db.ExecuteNonQuery(sql);
        }

        #endregion


        public bool CalculateMaintenancePrioritiesForWholeRoadsNetwork(RoadType type, int surveyNo, string user)
        {
            DataTable dt;
            switch (type)
            {
                case RoadType.Section:
                    dt = new MainStreet().GetMainStreetsHavingMaintenanceDecisions();
                    foreach (DataRow dr in dt.Rows)
                        CalculateMaintenancePrioritiesMainStreetSections(int.Parse(dr["ID3"].ToString()), surveyNo, user);

                    return true;

                case RoadType.Intersect:
                    dt = new MainStreet().GetMainStreetsHavingIntersectionsMaintenanceDecisions();
                    foreach (DataRow dr in dt.Rows)
                        CalculateMaintenancePrioritiesMainStreetSections(int.Parse(dr["ID3"].ToString()), surveyNo, user);
                    return true;

                case RoadType.RegionSecondarySt:
                    CalculateMaintenancePrioritiesRegions(surveyNo, user);
                    return true;

                default:
                    return false;
            }
        }


        #region Getting Survey Number

        public DataTable GetMainStreetIntersectionsAvailableSurveys(int mainStID)
        {
            if (mainStID == 0)
                return new DataTable();

            string sql = string.Format("SELECT SURVEY_NO, to_char(MAX(SURVEY_DATE),'DD/MM/YYYY','NLS_CALENDAR=''GREGORIAN''') as MBSURDATE, (SURVEY_NO || '- ' || to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy')) survey_title FROM MAINT_PRIORITY WHERE  MAIN_ST_ID={0} GROUP BY SURVEY_NO ", mainStID);
            return db.ExecuteQuery(sql);
        }

        public DataTable GetMainStreetAvailableSurveys(int mainStID)
        {
            if (mainStID == 0)
                return new DataTable();

            string sql = string.Format("SELECT SURVEY_NO, MAX(SURVEY_DATE) MBSURDATE, (SURVEY_NO || '- ' || to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy','NLS_CALENDAR=''GREGORIAN''')) survey_title FROM MAINT_PRIORITY WHERE  MAIN_ST_ID={0} GROUP BY SURVEY_NO ", mainStID);
            return db.ExecuteQuery(sql);
        }

        public DataTable GetRegionsAndMainStreetSectionIntersectionsSurveyNumber(string regionNo, string subdistrict, string districtName, string municName, bool forRegion, bool forSubdist,
           bool forDist, bool forMunic, int mainStID, bool lane, bool intersect)
        {
            if (forRegion || forSubdist || forDist || forMunic)
                return GetRegionDistrictAvailableSurveys(regionNo, subdistrict, districtName, municName, forRegion, forSubdist, forDist, forMunic, false);
            else
            {
                if (lane)
                    return GetMainStreetAvailableSurveys(mainStID);
                else if (intersect)
                    return GetMainStreetIntersectionsAvailableSurveys(mainStID);
                else
                    return new DataTable();
            }
        }

        public DataTable GetRegionDistrictAvailableSurveys(string regionNo, string subdistrict, string districtName, string municName, bool forRegion, bool forSubdist,
           bool forDist, bool forMunic, bool isRegionTotal)
        {
            string sql = "";

            if (forRegion || isRegionTotal)
            {
                if (string.IsNullOrEmpty(regionNo))
                    return new DataTable();

                sql = string.Format("SELECT SURVEY_NO, to_char(MAX(SURVEY_DATE),'DD/MM/YYYY','NLS_CALENDAR=''GREGORIAN''') as MSSURDATE, (SURVEY_NO|| '- '|| to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy','NLS_CALENDAR=''GREGORIAN''')) as survey_title  FROM MAINT_PRIORITY WHERE REGION_No='{0}' GROUP BY SURVEY_NO ", regionNo);
            }
            else if (forSubdist)
            {
                if (string.IsNullOrEmpty(subdistrict) || subdistrict == "0")
                    return new DataTable();

                sql = string.Format("SELECT SURVEY_NO,to_char(MAX(SURVEY_DATE),'DD/MM/YYYY','NLS_CALENDAR=''GREGORIAN''') as MBSURDATE, (SURVEY_NO|| '- '|| to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy','NLS_CALENDAR=''GREGORIAN''')) as survey_title FROM MAINT_PRIORITY  WHERE REGION_No in (select region_no from regions where subdistrict='{0}') GROUP BY SURVEY_NO ", subdistrict);
            }
            else if (forDist)
            {
                if (string.IsNullOrEmpty(districtName) || districtName == "0")
                    return new DataTable();

                sql = string.Format("SELECT SURVEY_NO, to_char(MAX(SURVEY_DATE),'DD/MM/YYYY','NLS_CALENDAR=''GREGORIAN''') as MBSURDATE, (SURVEY_NO|| '- '|| to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy','NLS_CALENDAR=''GREGORIAN''')) as survey_title FROM MAINT_PRIORITY  WHERE REGION_No in (select region_no from regions where DIST_NAME='{0}') GROUP BY SURVEY_NO ", districtName);
            }
            else if (forMunic)
            {
                if (string.IsNullOrEmpty(municName) || municName == "0")
                    return new DataTable();

                sql = string.Format("SELECT SURVEY_NO, to_char(MAX(SURVEY_DATE),'DD/MM/YYYY','NLS_CALENDAR=''GREGORIAN''') as MBSURDATE, (SURVEY_NO|| '- '|| to_char(MAX(SURVEY_DATE), 'dd/MM/yyyy','NLS_CALENDAR=''GREGORIAN''')) as survey_title FROM MAINT_PRIORITY  WHERE REGION_No in (select region_no from regions where MUNIC_NAME='{0}') GROUP BY SURVEY_NO ", municName);
            }

            if (!string.IsNullOrEmpty(sql))
                return db.ExecuteQuery(sql);
            else
                return new DataTable();
        }

        #endregion

    }
}
