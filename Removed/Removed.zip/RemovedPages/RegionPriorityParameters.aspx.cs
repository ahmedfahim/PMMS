﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL;

public partial class ASPX_Regions_RegionPriorityParameters : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[4] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            DataTable dt = new Region().GetRegionPriorityParameters(int.Parse(ddlRegions.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                ddlPopFactor.SelectedValue = dr["POP_FACTOR"].ToString();
                ddlCompleteFactor.SelectedValue = dr["COMPLETE_FACTOR"].ToString();

                pnlParams.Visible = true;
            }
            else
            {
                pnlParams.Visible = false;
                lblFeedback.Text = Feedback.NoData(Session["lang"].ToString());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            bool saved = new Region().UpdatePriorityParamters(int.Parse(ddlRegions.SelectedValue), int.Parse(ddlCompleteFactor.SelectedValue), int.Parse(ddlPopFactor.SelectedValue));
            lblFeedback.Text = saved ? Feedback.InsertSuccessfull(Session["lang"].ToString()) : Feedback.InsertException(Session["lang"].ToString());
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        pnlParams.Visible = false;
        ddlRegions_SelectedIndexChanged(sender, e);
    }

}
