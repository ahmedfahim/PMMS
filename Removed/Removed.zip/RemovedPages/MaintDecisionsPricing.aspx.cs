﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL.Lookups;

public partial class ASPX_Operations_MaintDecisionsPricing : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                radMaterial.Checked = false;
                radOperation.Checked = true;
                radOperation_CheckedChanged(sender, e);
                lblMaintenanceTotal.Text = MaintDecisionPricing.GetMaintenanceTotalCost(0).ToString("N2");
            }

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void rntxtPrice_TextChanged(object sender, EventArgs e)
    {
        if (rntxtPrice.Value != null && rntxtQty.Value != null)
            rntxtTotal.Value = rntxtPrice.Value * rntxtQty.Value;
        else
            rntxtTotal.Value = null;
    }

    protected void rntxtQty_TextChanged(object sender, EventArgs e)
    {
        rntxtPrice_TextChanged(sender, e);
    }

    protected void radOperation_CheckedChanged(object sender, EventArgs e)
    {
        ddlMaterials.Enabled = false;
        ddlOperations.Enabled = true;
    }

    protected void radMaterial_CheckedChanged(object sender, EventArgs e)
    {
        ddlOperations.Enabled = false;
        ddlMaterials.Enabled = true;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());


            bool saved = false;
            string lang = Session["lang"].ToString();            

            if (radMaterial.Checked)
                saved = new MaintDecisionPricing().InsertMaintDecisionMaterial(int.Parse(ddlMaintDecisions.SelectedValue), int.Parse(ddlMaterials.SelectedValue),
                    int.Parse(ddlUnits.SelectedValue), (decimal)rntxtQty.Value, (decimal)rntxtPrice.Value);
            else if (radOperation.Checked)
                saved = new MaintDecisionPricing().InsertMaintDecisionOperation(int.Parse(ddlMaintDecisions.SelectedValue), int.Parse(ddlOperations.SelectedValue),
                   int.Parse(ddlUnits.SelectedValue), (decimal)rntxtQty.Value, (decimal)rntxtPrice.Value);


            if (saved)
            {
                gvPricing.DataBind();
                ClearTexts(sender, e);

                lblMaintenanceTotal.Text = MaintDecisionPricing.GetMaintenanceTotalCost(int.Parse(ddlMaintDecisions.SelectedValue)).ToString("N2");
                lblFeedback.Text = Feedback.InsertSuccessfull(lang);
            }
            else
                lblFeedback.Text = Feedback.InsertException(lang);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        ClearTexts(sender, e);
    }

    private void ClearTexts(object sender, EventArgs e)
    {
        radMaterial.Checked = false;
        radOperation.Checked = true;
        radOperation_CheckedChanged(sender, e);

        ddlMaterials.SelectedValue = "0";
        ddlOperations.SelectedValue = "0";
        ddlUnits.SelectedValue = "0";

        rntxtPrice.Text = "";
        rntxtQty.Text = "";
        rntxtTotal.Text = "";
    }

    protected void ddlOperations_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string lang = Session["lang"].ToString();
            DataTable dt = new MaintOperations().GetByID(int.Parse(ddlOperations.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlUnits.SelectedValue = dt.Rows[0]["OPERATION_UNIT_ID"].ToString();
                rntxtPrice.Text = decimal.Parse(dt.Rows[0]["FIXED_PRICE"].ToString()).ToString("N2");
                rntxtPrice_TextChanged(sender, e);
            }
            else
                lblFeedback.Text = Feedback.NoData(lang);

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMaterials_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string lang = Session["lang"].ToString();
            DataTable dt = new MaintMaterial().GetByID(int.Parse(ddlMaterials.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                ddlUnits.SelectedValue = dt.Rows[0]["MATERIAL_UNIT_ID"].ToString();
                rntxtPrice.Text = decimal.Parse(dt.Rows[0]["MATERIAL_PRICE"].ToString()).ToString("N2");
                rntxtPrice_TextChanged(sender, e);
            }
            else
                lblFeedback.Text = Feedback.NoData(lang);

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMaintDecisions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            pnlInsert.Visible = (ddlMaintDecisions.SelectedValue != "0");
            lblMaintenanceTotal.Text = MaintDecisionPricing.GetMaintenanceTotalCost(int.Parse(ddlMaintDecisions.SelectedValue)).ToString("N2");
            gvPricing.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void odsMaintenancePricing_Updated(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
        {
            try
            {
                lblFeedback.Text = Feedback.UpdateSuccessfull(Session["lang"].ToString());
                lblMaintenanceTotal.Text = MaintDecisionPricing.GetMaintenanceTotalCost(int.Parse(ddlMaintDecisions.SelectedValue)).ToString("N2");
            }
            catch (Exception ex)
            {
                lblFeedback.Text = ex.Message;
            }
        }
    }

    protected void odsMaintenancePricing_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
        {
            try
            {
                lblFeedback.Text = Feedback.DeleteSuccessfull(Session["lang"].ToString());
                lblMaintenanceTotal.Text = MaintDecisionPricing.GetMaintenanceTotalCost(int.Parse(ddlMaintDecisions.SelectedValue)).ToString("N2");
            }
            catch (Exception ex)
            {
                lblFeedback.Text = ex.Message;
            }
        }
    }

    protected void gvPricing_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        if (!bool.Parse(Session["canEdit"].ToString()))
        {
            lblFeedback.Text = Feedback.NoPermissions();
            e.Cancel = true;
        }
    }

    protected void gvPricing_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (!bool.Parse(Session["canEdit"].ToString()))
        {
            lblFeedback.Text = Feedback.NoPermissions();
            e.Cancel = true;
        }
    }

}
