﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL;

public partial class ASPX_Intersections_IntersectionPriorityParams : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[4] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected override void InitializeCulture()
    {
        string culture = Session["lang"].ToString();
        if (string.IsNullOrEmpty(culture))
            culture = "Auto";

        //Use this
        UICulture = culture;
        Culture = culture;
        //OR This
        //if (culture != "Auto")
        //{
        //    System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(culture);
        //    System.Threading.Thread.CurrentThread.CurrentCulture = ci;
        //    System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
        //}

        base.InitializeCulture();
    }


    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            // align="right"
            lblFeedback.Text = "";
            pnlParams.Visible = false;

            string select = (Culture == "en-GB") ? "Select" : "اختيار";

            ddlMainStreetIntersection.Items.Clear();
            ddlMainStreetIntersection.Items.Add(new ListItem(select, "0"));
            ddlMainStreetIntersection.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            bool saved = new Intersection().UpdatePriorityParamters(int.Parse(ddlMainStreetIntersection.SelectedValue), int.Parse(ddlStreet1.SelectedValue),
                int.Parse(ddlStreet2.SelectedValue));

            lblFeedback.Text = saved ? Feedback.InsertSuccessfull(Session["lang"].ToString()) : Feedback.InsertException(Session["lang"].ToString());
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        pnlParams.Visible = false;

        ddlMainStIntersect_SelectedIndexChanged(sender, e);
    }

    protected void ddlMainStIntersect_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            DataTable dt = new Intersection().GetIntersectionPriorityParameters(int.Parse(ddlMainStreetIntersection.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                ddlStreet1.SelectedValue = dr["STREET1_FACTOR"].ToString();
                ddlStreet2.SelectedValue = dr["STREET2_FACTOR"].ToString();

                pnlParams.Visible = true;
            }
            else
            {
                pnlParams.Visible = false;
                lblFeedback.Text = Feedback.NoData(Session["lang"].ToString());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

}
