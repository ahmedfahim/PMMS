﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL.UDI;
using System.Diagnostics;
using System.Threading;
using System.Data;
using JpmmsClasses;

public partial class ASPX_Sections_UdiSections : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[2] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            radlOldSurveys.DataBind();
            gvSectionsUDI.DataSource = null;
            gvSectionsUDI.DataBind();

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }


    private void CalculateUDI()
    {
        SectionsUDI udi = new SectionsUDI();
        int st = int.Parse(ddlMainStreets.SelectedValue);
        int survey = int.Parse(radlOldSurveys.SelectedValue.ToString());
        string user = Session["UserName"].ToString();

        bool result = udi.CalculateMainStreetSectionsUDI(st, survey, user);
        if (result)
        {
            lblFeedback.Text = "تم الحساب بنجاح";
            DataTable dt = udi.GetSectionsUdiByMainStreet(st, survey, true);
            if (dt.Rows.Count == 0)
                throw new Exception("لم يكتمل حساب معامل الرصف لعدم اكتمال مسح كل العينات");

            gvSectionsUDI.DataSource = dt;
            gvSectionsUDI.DataBind();

            ThreadResults.Add(RequestID, dt);
        }
        else
        {
            lblFeedback.Text = "فشلت عملية الحساب";
            gvSectionsUDI.DataSource = null;
            gvSectionsUDI.DataBind();
        }
    }


    protected Guid RequestID;

    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            if (ddlMainStreets.SelectedValue == "0")
                throw new Exception("الرجاء اختيار الطريق الرئيسي");
            else if (radlOldSurveys.SelectedIndex < 0)
                throw new Exception("الرجاء اختيار رقم المسح");


            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(CalculateUDI);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("result.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);

        }
        catch (Exception ex)
        {
            Debug.Print(ex.Message);
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            ddlMainStreets.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);

            gvSectionsUDI.DataSource = null;
            gvSectionsUDI.DataBind();

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

  
}