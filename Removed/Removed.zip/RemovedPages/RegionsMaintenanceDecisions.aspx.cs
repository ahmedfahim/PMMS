﻿using System;
using System.Collections;
using System.Threading;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;
using JpmmsClasses;

public partial class ASPX_Regions_RegionsMaintenanceDecisions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Permissions"] == null || Session["Permissions"].ToString()[3] != '1')
                Response.Redirect("~/ASPX/Default.aspx", false);

            radByRegionsAreaName.Checked = false;
            radbyMunicName.Checked = false;
            raddistrict.Checked = false;
            radRegion.Checked = true;
            radRegion_CheckedChanged(sender, e);
        }
    }

    protected void radRegion_CheckedChanged(object sender, EventArgs e)
    {
        ddlRegions.Enabled = true;
        ddlDistricts.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = false;
    }

    protected void raddistrict_CheckedChanged(object sender, EventArgs e)
    {
        ddlDistricts.Enabled = true;
        ddlRegions.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = false;
    }

    private void Calculate()
    {
        bool result = false;

        MaintenanceDecisions md = new MaintenanceDecisions();
        int regionID = int.Parse(ddlRegions.SelectedValue);
        int survey = int.Parse(radlOldSurveys.SelectedValue.ToString());
        string user = Session["UserName"].ToString();

        //btnCalc.Enabled = false;
        if (radRegion.Checked)
            result = md.PrepareRegionSecondaryStreetsMaintenanceDecisions(regionID, survey, user);
        else if (raddistrict.Checked)
            result = md.PrepareSubdistrictSecondaryStreetsMaintenanceDecisions(ddlDistricts.SelectedValue, survey, user);
        else if (radByRegionsAreaName.Checked)
            result = md.PrepareDistrictSecondaryStreetsMaintenanceDecisions(ddlDistrictNames.SelectedValue, survey, user);
        else if (radbyMunicName.Checked)
            result = md.PrepareMunicipalitySecondaryStreetsMaintenanceDecisions(ddlMunic.SelectedValue, survey, user);

        if (result)
        {
            lblFeedback.Text = "تم الحساب بنجاح";

            DataTable dt = new DataTable();
            if (radRegion.Checked)
                dt= md.GetRegionSecondaryStreetsMaintenanceDecisions(regionID, survey);
            else if (raddistrict.Checked)
                dt= md.GetSubdistrictSecondaryStreetsMaintenanceDecisions(ddlDistricts.SelectedValue, survey);
            else if (radByRegionsAreaName.Checked)
                dt= md.GetDistrictSecondaryStreetsMaintenanceDecisions(ddlDistrictNames.SelectedValue, survey);
            else if (radbyMunicName.Checked)
                dt = md.GetMunicipalitySecondaryStreetsMaintenanceDecisions(ddlMunic.SelectedValue, survey);

            gvSecondaryMaintDecisions.DataSource = dt;
            gvSecondaryMaintDecisions.DataBind();

            ThreadResults.Add(RequestID, dt);
        }
        else
        {
            lblFeedback.Text = "فشلت عملية الحساب";
            gvSecondaryMaintDecisions.DataSource = null;
            gvSecondaryMaintDecisions.DataBind();
        }
    }

    protected Guid RequestID;

    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());


            if (radRegion.Checked && ddlRegions.SelectedValue == "0")
                throw new Exception("الرجاء اختيار المنطقة الفرعية");
            else if (raddistrict.Checked && ddlDistricts.SelectedValue == "0")
                throw new Exception("الرجاء اختيار الحي الفرعي");
            else if (radByRegionsAreaName.Checked && ddlDistrictNames.SelectedValue == "0")
                throw new Exception("الرجاء اختيار منطقة الأحياء الفرعية");
            else if (radbyMunicName.Checked && ddlMunic.SelectedValue == "0")
                throw new Exception("الرجاء اختيار البلدية الفرعية");
            else if (radlOldSurveys.SelectedIndex < 0)
                throw new Exception("الرجاء اختيار رقم المسح");

            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(Calculate);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("MdResults.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
        finally
        {
            btnCalc.Enabled = true;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            //radlOldSurveys.SelectedIndex = -1;
            gvSecondaryMaintDecisions.DataSource = null;
            gvSecondaryMaintDecisions.DataBind();

            radRegion.Checked = true;
            raddistrict.Checked = false;
            radRegion_CheckedChanged(sender, e);

            ddlDistricts.SelectedValue = "0";
            ddlRegions.SelectedValue = "0";
            ddlRegions_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            radlOldSurveys.DataBind();
            gvSecondaryMaintDecisions.DataSource = null;
            gvSecondaryMaintDecisions.DataBind();

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlDistricts_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void ddlDistrictNames_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void ddlMunic_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void radbyMunicName_CheckedChanged(object sender, EventArgs e)
    {
        ddlRegions.Enabled = false;
        ddlDistricts.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = true;
    }

    protected void radByRegionsAreaName_CheckedChanged(object sender, EventArgs e)
    {
        ddlRegions.Enabled = false;
        ddlDistricts.Enabled = false;
        ddlDistrictNames.Enabled = true;
        ddlMunic.Enabled = false;
    }

    protected void radlOldSurveys_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

}
