﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL.UDI;
using System.Threading;
using System.Data;
using JpmmsClasses;

public partial class ASPX_Intersections_IntersectionUDI : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[2] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            radlOldSurveys.DataBind();

            gvIntersectUDI.DataSource = null;
            gvIntersectUDI.DataBind();

            //if (radlOldSurveys.Items.Count == 1)
            radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }


    private void CalculateUDI()
    {
        IntersectionUDI udi = new IntersectionUDI();
        int mainStID = int.Parse(ddlMainStreets.SelectedValue);
        int survey = int.Parse(radlOldSurveys.SelectedValue.ToString());
        string user = Session["UserName"].ToString();

        bool result = udi.CalculateMainStreetIntersectionsUDI(mainStID, survey, user);
        if (result)
        {
            lblFeedback.Text = "تم الحساب بنجاح";
            DataTable dt = udi.GetMainStreetIntersectionUDI(mainStID, survey);
            gvIntersectUDI.DataSource = dt;
            gvIntersectUDI.DataBind();

            ThreadResults.Add(RequestID, dt);
        }
        else
        {
            lblFeedback.Text = "فشلت عملية الحساب";
            gvIntersectUDI.DataSource = null;
            gvIntersectUDI.DataBind();
        }
    }


    protected Guid RequestID;

    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            btnCalc.Enabled = false;

            if (ddlMainStreets.SelectedValue == "0")
                throw new Exception(Feedback.NoMainStreetSelected(Session["lang"].ToString()));
            else if (radlOldSurveys.SelectedIndex == -1)
                throw new Exception(Feedback.NoSurveyDateNum(Session["lang"].ToString()));


            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(CalculateUDI);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("result.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
        finally
        {
            btnCalc.Enabled = true;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            ddlMainStreets.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);

            gvIntersectUDI.DataSource = null;
            gvIntersectUDI.DataBind();

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

}