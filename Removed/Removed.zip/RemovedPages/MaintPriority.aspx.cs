﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;

public partial class ASPX_Operations_MaintPriority : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[8] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);

        if (!IsPostBack)
            chkSections_CheckedChanged(sender, e);
    }

    protected void chkSections_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            radlOldSurveys.DataBind();
            radlOldSurveys.SelectedIndex = (radlOldSurveys.Items.Count == 0) ? -1 : 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void chkIntersections_CheckedChanged(object sender, EventArgs e)
    {
        chkSections_CheckedChanged(sender, e);
    }

    protected void chkRegions_CheckedChanged(object sender, EventArgs e)
    {
        chkSections_CheckedChanged(sender, e);
    }

    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            bool finished = false;
            int survey = int.Parse(radlOldSurveys.SelectedValue);
            if (chkSections.Checked)
                finished = new MaintenancePriorities().CalculateMaintenancePrioritiesForWholeRoadsNetwork(RoadType.Section, survey, Session["UserName"].ToString());
            else if (chkIntersections.Checked)
                finished = new MaintenancePriorities().CalculateMaintenancePrioritiesForWholeRoadsNetwork(RoadType.Intersect, survey, Session["UserName"].ToString());
            else if (chkRegions.Checked)
                finished = new MaintenancePriorities().CalculateMaintenancePrioritiesForWholeRoadsNetwork(RoadType.RegionSecondarySt, survey, Session["UserName"].ToString());

            lblFeedback.Text = finished ? "تم حساب أولويات الصيانة بنجاح" : "فشل حساب أولويات الصيانة";
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            chkSections_CheckedChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }
}