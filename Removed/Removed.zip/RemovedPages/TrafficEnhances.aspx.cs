﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;

public partial class ASPX_Operations_TrafficEnhances : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[8] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void odsTraffEnahnces_Updated(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.UpdateSuccessfull(Session["lang"].ToString());
    }

    protected void odsTraffEnahnces_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.DeleteSuccessfull(Session["lang"].ToString());
    }

    protected void odsTraffEnahnces_Inserted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.InsertSuccessfull(Session["lang"].ToString());
    }

    protected void gvTraffEnahnces_SelectedIndexChanged(object sender, EventArgs e)
    {
        bool visible= !string.IsNullOrEmpty(gvTraffEnahnces.SelectedValue.ToString());
        pnlDetails.Visible = visible;
        pnlLocations.Visible = visible;

        btnCancelLocation_Click(sender, e);
        //gvTrafficEnhanceDetails.SelectedIndex = -1;
    }

    protected void odsTrafficEnhanceDetails_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.DeleteSuccessfull(Session["lang"].ToString());
    }

    protected void odsTrafficEnhanceDetails_Updated(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.UpdateSuccessfull(Session["lang"].ToString());
    }

    protected void odsTrafficEnhanceDetails_Inserted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
        {
            lblFeedback.Text = Feedback.InsertSuccessfull(Session["lang"].ToString());
            //gvTrafficEnhanceDetails.SelectedIndex = -1;
            pnlLocations.Visible = false;
            //gvTrafficEnhanceDetails_SelectedIndexChanged(sender, new EventArgs());
        }
    }

    protected void gvTrafficEnhanceDetails_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";
            pnlLocations.Visible = !string.IsNullOrEmpty(gvTraffEnahnces.SelectedValue.ToString());

            radSection.Checked = true;
            radIntersect.Checked = false;
            radRegion.Checked = false;
            radDistricts.Checked = false;
            radMunics.Checked = false;
            radSection_CheckedChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void radSection_CheckedChanged(object sender, EventArgs e)
    {
        ddlMainStreets.Visible = true;
        ddlMainStreetSection.Visible = true;
        ddlMainStreetIntersection.Visible = false;
        ddlRegions.Visible = false;
        ddlRegionSecondaryStreets.Visible = false;
        ddlRegionNames.Visible = false;
        ddlMunic.Visible = false;

        ddlMainStreets.SelectedValue = "0";
        ddlMainStreets_SelectedIndexChanged(sender, e);
    }

    protected void radIntersect_CheckedChanged(object sender, EventArgs e)
    {
        ddlMainStreets.Visible = true;
        ddlMainStreetSection.Visible = false;
        ddlMainStreetIntersection.Visible = true;
        ddlRegions.Visible = false;
        ddlRegionSecondaryStreets.Visible = false;
        ddlRegionNames.Visible = false;
        ddlMunic.Visible = false;

        ddlMainStreets.SelectedValue = "0";
        ddlMainStreets_SelectedIndexChanged(sender, e);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            string select = (Session["lang"].ToString().Contains("ar")) ? "اختيار" : "Select";

            if (radSection.Checked)
            {
                ddlMainStreetSection.Items.Clear();
                ddlMainStreetSection.Items.Add(new ListItem(select, "0"));
                ddlMainStreetSection.DataBind();
            }
            else if (radIntersect.Checked)
            {
                ddlMainStreetIntersection.Items.Clear();
                ddlMainStreetIntersection.Items.Add(new ListItem(select, "0"));
                ddlMainStreetIntersection.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radRegion_CheckedChanged(object sender, EventArgs e)
    {
        ddlMainStreets.Visible = false;
        ddlMainStreetSection.Visible = false;
        ddlMainStreetIntersection.Visible = false;
        ddlRegions.Visible = true;
        ddlRegionSecondaryStreets.Visible = true;
        ddlRegionNames.Visible = false;
        ddlMunic.Visible = false;

        ddlRegions.SelectedValue = "0";
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string select = (Session["lang"].ToString().Contains("ar")) ? "اختيار" : "Select";

            ddlRegionSecondaryStreets.Items.Clear();
            ddlRegionSecondaryStreets.Items.Add(new ListItem(select, "0"));
            ddlRegionSecondaryStreets.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnAddLocation_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            lblAddFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            bool saved = false;
            int trafficEnahnaceID = int.Parse(gvTraffEnahnces.SelectedValue.ToString());
            int sectionID = int.Parse(ddlMainStreetSection.SelectedValue);
            int mainStID = int.Parse(ddlMainStreets.SelectedValue);
            int intersectID = int.Parse(ddlMainStreetIntersection.SelectedValue);
            string dist = ddlRegionNames.SelectedValue;
            string munic = ddlMunic.SelectedValue;

            if (radSection.Checked)
                saved = new TrafficEnhances().AddTrafficEnhanceDetailLocations(trafficEnahnaceID, radSection.Checked, radIntersect.Checked, radRegion.Checked, mainStID,
                    sectionID, radDistricts.Checked, radMunics.Checked, "");
            else if (radIntersect.Checked)
                saved = new TrafficEnhances().AddTrafficEnhanceDetailLocations(trafficEnahnaceID, radSection.Checked, radIntersect.Checked, radRegion.Checked, mainStID,
                    intersectID, radDistricts.Checked, radMunics.Checked, "");
            else if (radRegion.Checked)
                saved = new TrafficEnhances().AddTrafficEnhanceDetailLocations(trafficEnahnaceID, radSection.Checked, radIntersect.Checked, radRegion.Checked,
                    int.Parse(ddlRegions.SelectedValue), int.Parse(ddlRegionSecondaryStreets.SelectedValue), radDistricts.Checked, radMunics.Checked, "");
            else if (radDistricts.Checked)
                saved = new TrafficEnhances().AddTrafficEnhanceDetailLocations(trafficEnahnaceID, radSection.Checked, radIntersect.Checked, radRegion.Checked,
                  int.Parse(ddlRegions.SelectedValue), int.Parse(ddlRegionSecondaryStreets.SelectedValue), radDistricts.Checked, radMunics.Checked, dist);
            else if (radMunics.Checked)
                saved = new TrafficEnhances().AddTrafficEnhanceDetailLocations(trafficEnahnaceID, radSection.Checked, radIntersect.Checked, radRegion.Checked,
                  int.Parse(ddlRegions.SelectedValue), int.Parse(ddlRegionSecondaryStreets.SelectedValue), radDistricts.Checked, radMunics.Checked, munic);

            if (saved)
            {
                lblAddFeedback.Text = Feedback.InsertSuccessfull(Session["lang"].ToString());
                gvLocations.DataBind();
            }
            else
                lblAddFeedback.Text = Feedback.InsertException(Session["lang"].ToString());

        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void btnCancelLocation_Click(object sender, EventArgs e)
    {
        lblAddFeedback.Text = "";

        radIntersect.Checked = false;
        radRegion.Checked = false;
        radSection.Checked = true;
        radSection_CheckedChanged(sender, e);
    }

    protected void odsTrafficEnhanceLocations_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblAddFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
        {
            lblAddFeedback.Text = Feedback.DeleteSuccessfull(Session["lang"].ToString());
            gvLocations.DataBind();
        }
    }

    private bool DataAreValid()
    {
        if (string.IsNullOrEmpty(DETAILSTextBox.Text))
        {
            DETAILSTextBox.Focus();
            throw new Exception("الرجاء إدخال بيان تفاصيل التحسين المروري");
        }
        else if (string.IsNullOrEmpty(CONTRACT_NOTextBox.Text))
        {
            CONTRACT_NOTextBox.Focus();
            throw new Exception("الرجاء إدخال رقم العقد");
        }
        else if (string.IsNullOrEmpty(CONTRACT_NAMETextBox.Text))
        {
            CONTRACT_NAMETextBox.Focus();
            throw new Exception("الرجاء إدخال اسم العقد");
        }
        else if (ddlContractors.SelectedValue == "0")
        {
            ddlContractors.Focus();
            throw new Exception("الرجاء اختيار المقاول");
        }
        else if (raddtpBegin.SelectedDate == null)
        {
            raddtpBegin.Focus();
            throw new Exception("الرجاء إدخال تاريخ العقد");
        }
        else if (raddtpWorkBegin.SelectedDate == null)
        {
            raddtpWorkBegin.Focus();
            throw new Exception("الرجاء إدخال تاريخ بدء التنفيذ");
        }
        else if (raddtpEnd.SelectedDate == null)
        {
            raddtpEnd.Focus();
            throw new Exception("الرجاء إدخال تاريخ الانتهاء");
        }
        else if (raddtpEnd.SelectedDate < raddtpWorkBegin.SelectedDate)
        {
            raddtpEnd.Focus();
            throw new Exception("تاريخ الانتهاء لايمكن ان يكون قبل تاريخ بدء التنفيذ");
        }
        else
            return true;
    }

    protected void btnAddContract_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            if (chkContract.Checked && !DataAreValid())
                return;

            bool saved = new TrafficEnhances().Insert(DETAILSTextBox.Text, chkContract.Checked, CONTRACT_NOTextBox.Text, CONTRACT_NAMETextBox.Text,
                int.Parse(ddlContractors.SelectedValue), raddtpBegin.SelectedDate, raddtpWorkBegin.SelectedDate, raddtpEnd.SelectedDate);

            //bool saved = new TrafficEnhances().Insert(CONTRACT_NOTextBox.Text, CONTRACT_NAMETextBox.Text, int.Parse(ddlContractors.SelectedValue),
            //    ((DateTime)raddtpBegin.SelectedDate).ToString("dd/MM/yyyy"), ((DateTime)raddtpWorkBegin.SelectedDate).ToString("dd/MM/yyyy"),
            //    ((DateTime)raddtpEnd.SelectedDate).ToString("dd/MM/yyyy"));

            if (saved)
            {
                lblFeedback.Text = Feedback.InsertSuccessfull(Session["lang"].ToString());
                gvTraffEnahnces.DataBind();
            }
            else
                lblFeedback.Text = Feedback.InsertException(Session["lang"].ToString());
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancelContract_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";

        CONTRACT_NOTextBox.Text = "";
        CONTRACT_NAMETextBox.Text = "";
        ddlContractors.SelectedValue = "0";

        raddtpBegin.SelectedDate = null;
        raddtpWorkBegin.SelectedDate = null;
        raddtpEnd.SelectedDate = null;

        chkContract.Checked = false;
        chkContract_CheckedChanged(sender, e);
    }

    protected void btnAddContractor_Click(object sender, EventArgs e)
    {
        AddContractorMini1.Display();
    }    

    protected void OnOnContractorAdded()  //object sender, EventArgs e)
    {
        try
        {
            //((DropDownList)FormView1.FindControl("ddlContractors")).DataBind();
            //DropDownList ddl = ((DropDownList)FormView1.FindControl("ddlContractors"));
            ddlContractors.Items.Clear();
            ddlContractors.Items.Add(new ListItem("اختيار", "0"));
            ddlContractors.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radDistricts_CheckedChanged(object sender, EventArgs e)
    {
        ddlMainStreets.Visible = false;
        ddlMainStreetSection.Visible = false;
        ddlMainStreetIntersection.Visible = false;
        ddlRegions.Visible = false;
        ddlRegionSecondaryStreets.Visible = false;
        ddlRegionNames.Visible = true;
        ddlMunic.Visible = false;

        ddlRegionNames.SelectedValue = "0";
    }

    protected void radMunics_CheckedChanged(object sender, EventArgs e)
    {
        ddlMainStreets.Visible = false;
        ddlMainStreetSection.Visible = false;
        ddlMainStreetIntersection.Visible = false;
        ddlRegions.Visible = false;
        ddlRegionSecondaryStreets.Visible = false;
        ddlRegionNames.Visible = false;
        ddlMunic.Visible = true;

        ddlMunic.SelectedValue = "0";
    }

    protected void chkContract_CheckedChanged(object sender, EventArgs e)
    {
        pnlContract.Visible = chkContract.Checked;
    }

    protected void gvTraffEnahnces_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        if (!bool.Parse(Session["canEdit"].ToString()))
        {
            lblFeedback.Text = Feedback.NoPermissions();
            e.Cancel = true;
        }
    }

    protected void gvTraffEnahnces_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        if (!bool.Parse(Session["canEdit"].ToString()))
        {
            lblFeedback.Text = Feedback.NoPermissions();
            e.Cancel = true;
        }
    }

    protected void gvLocations_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        if (!bool.Parse(Session["canEdit"].ToString()))
        {
            lblFeedback.Text = Feedback.NoPermissions();
            e.Cancel = true;
        }
    }

}