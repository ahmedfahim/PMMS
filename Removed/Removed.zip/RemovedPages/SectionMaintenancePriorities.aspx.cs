﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using JpmmsClasses.BL;
using JpmmsClasses.BL.DistressEntry;

public partial class ASPX_Sections_SectionMaintenancePriorities : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[4] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void btnDoMaintainPrio_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            btnDoMaintainPrio.Enabled = false;

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());
                

            if (ddlMainStreets.SelectedValue == "0")
                throw new Exception(Feedback.NoMainStreetSelected("ar"));
            else if (radlOldSurveys.SelectedValue == null)
                throw new Exception(Feedback.NoSurveyDateNum("ar"));


            MaintenancePriorities mp = new MaintenancePriorities();

            int mainStID = int.Parse(ddlMainStreets.SelectedValue);
            int surveyNo = int.Parse(radlOldSurveys.SelectedValue);
            string user = Session["UserName"].ToString();

            bool saved = mp.CalculateMaintenancePrioritiesMainStreetSections(mainStID, surveyNo, user);
            if (saved)
            {
                lblFeedback.Text = "تم حساب أولويات الصيانة بنجاح";
                // prepre to show report
                DataTable dt = mp.GetMaintenancePrioritiesForMainStreetReport(mainStID, surveyNo);
                if (dt.Rows.Count > 0)
                    lbtnShowReport.Visible = true;
                else
                    lbtnShowReport.Visible = false;
            }
            else
            {
                lblFeedback.Text = "فشل حساب أولويات الصيانة";
                lbtnShowReport.Visible = false;
            }

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
        finally
        {
            btnDoMaintainPrio.Enabled = true;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            ddlMainStreets.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);

            lblFeedback.Text = "";
            lbtnShowReport.Visible = false;

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            radlOldSurveys.DataBind();
            lbtnShowReport.Visible = false;

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void lbtnShowReport_Click(object sender, EventArgs e)
    {
        try
        {
            int mainStID = int.Parse(ddlMainStreets.SelectedValue);
            int surveyNo = int.Parse(radlOldSurveys.SelectedValue);
            DataTable dt = new MaintenancePriorities().GetMaintenancePrioritiesForMainStreetReport(mainStID, surveyNo);
            if (dt.Rows.Count > 0)
            {
                //Session.Add("option", "radSection");
                Session.Add("ReportData", dt);
                string url = "ViewSectionMaintenancePrioritiesReport.aspx";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

}