﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using JpmmsClasses.BL;
using JpmmsClasses.BL.DistressEntry;

public partial class ASPX_Regions_RegionMaintenancePriorities : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Permissions"] == null || Session["Permissions"].ToString()[4] != '1')
                Response.Redirect("~/ASPX/Default.aspx", false);

            ddlRegions_SelectedIndexChanged(sender, e);
        }
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            radlOldSurveys.DataBind();
            lbtnShowReport.Visible = false;
            btnDoMaintainPrio.Enabled = true;

            //if (radlOldSurveys.Items.Count == 1)
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        lbtnShowReport.Visible = false;
        btnDoMaintainPrio.Enabled = true;
    }

    protected void lbtnShowReport_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (radlOldSurveys.SelectedIndex == -1)
                throw new Exception(Feedback.NoSurveyDateNum(Session["lang"].ToString()));

            int surveyNo = int.Parse(radlOldSurveys.SelectedValue);
            DataTable dt = new MaintenancePriorities().GetMaintenancePrioritiesForRegionsReport(surveyNo);
            if (dt.Rows.Count > 0)  
            {
                //Session.Add("option", "radSection");
                Session.Add("ReportData", dt);
                string url = "ViewRegionMaintenancePrioritiesReport.aspx";
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnDoMaintainPrio_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            btnDoMaintainPrio.Enabled = false;
            if (radlOldSurveys.SelectedIndex == -1)
                throw new Exception(Feedback.NoSurveyDateNum("lang"));


            MaintenancePriorities mp = new MaintenancePriorities();
            int surveyNo = int.Parse(radlOldSurveys.SelectedValue);
            string user = Session["UserName"].ToString();

            bool saved = mp.CalculateMaintenancePrioritiesRegions(surveyNo, user);
            if (saved)
            {
                lblFeedback.Text = "تم حساب أولويات الصيانة بنجاح";
                // prepre to show report
                DataTable dt = mp.GetMaintenancePrioritiesForRegionsReport(surveyNo);
                if (dt.Rows.Count > 0)
                    lbtnShowReport.Visible = true;
                else
                    lbtnShowReport.Visible = false;
            }
            else
            {
                lblFeedback.Text = "فشل حساب أولويات الصيانة";
                lbtnShowReport.Visible = false;
            }

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
        finally
        {
            btnDoMaintainPrio.Enabled = true;
        }
    }

}
