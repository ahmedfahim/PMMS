﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;

public partial class ASPX_SurveyingInfo_SurveyingInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Permissions"] == null || Session["Permissions"].ToString()[5] != '1')
                Response.Redirect("~/ASPX/Default.aspx", false);

            radSection_CheckedChanged(sender, e);
        }
    }

    protected void radRegionSecondary_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            pnlMainSt.Visible = false;
            pnlRegions.Visible = true;
            ddlMainStreets.Visible = false;
            ddlMainStreetSection.Visible = false;
            ddlMainStreetIntersection.Visible = false;

            //ddlRegions.Visible = true;
            ddlRegions.SelectedValue = "0";
            pnlSurvey.Visible = false;
            btnCancel_Click(sender, e);

            hID.Value = ddlRegions.SelectedValue;
            gvSurveyorJob.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radIntersection_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            pnlMainSt.Visible = true;
            ddlMainStreets.Visible = true;
            ddlMainStreetSection.Visible = false;
            pnlRegions.Visible = false;
            //ddlRegions.Visible = false;

            ddlMainStreetIntersection.Visible = true;
            //ddlMainStreetIntersection.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);
            ddlMainStreetIntersection_SelectedIndexChanged(sender, e);

            pnlSurvey.Visible = false;
            btnCancel_Click(sender, e);

            hID.Value = ddlMainStreets.SelectedValue;
            gvSurveyorJob.DataBind();

            Session["MainStreetID"] = ddlMainStreets.SelectedValue;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radSection_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            pnlMainSt.Visible = true;
            ddlMainStreets.Visible = true;
            ddlMainStreetIntersection.Visible = false;
            pnlRegions.Visible = false;
            //ddlRegions.Visible = false;

            ddlMainStreetSection.Visible = true;
            //ddlMainStreetSection.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);
            ddlMainStreetSection_SelectedIndexChanged(sender, e);

            pnlSurvey.Visible = false;
            btnCancel_Click(sender, e);

            hID.Value = ddlMainStreets.SelectedValue;
            gvSurveyorJob.DataBind();

            Session["MainStreetID"] = ddlMainStreets.SelectedValue;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            pnlSurvey.Visible = false;
            hID.Value = ddlMainStreets.SelectedValue;
            string select = Session["lang"].ToString().Contains("ar") ? "اختيار" : "select";

            if (radSection.Checked)
            {
                ddlMainStreetSection.Items.Clear();
                ddlMainStreetSection.Items.Add(new ListItem(select, "0"));
                ddlMainStreetSection.DataBind();
            }
            else if (radIntersection.Checked)
            {
                ddlMainStreetIntersection.Items.Clear();
                ddlMainStreetIntersection.Items.Add(new ListItem(select, "0"));
                ddlMainStreetIntersection.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreetSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        pnlSurvey.Visible = (ddlMainStreetSection.SelectedValue != "0");
        hID.Value = ddlMainStreets.SelectedValue; //ddlMainStreetSection.SelectedValue;
    }

    protected void ddlMainStreetIntersection_SelectedIndexChanged(object sender, EventArgs e)
    {
        pnlSurvey.Visible = (ddlMainStreetIntersection.SelectedValue != "0");
        hID.Value = ddlMainStreets.SelectedValue; //ddlMainStreetIntersection.SelectedValue;
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        pnlSurvey.Visible = (ddlRegions.SelectedValue != "0");
        hID.Value = ddlRegions.SelectedValue;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            //if (string.IsNullOrEmpty(hID.Value))
            //    throw new Exception("الرجاء اختيار العنصر (مقطع،تقاطع، شارع فرعي) الذي قد تم مسحه");
            //else 
            if (raddtpIssueDate.SelectedDate == null || raddtpDeliveryDate.SelectedDate == null)
                throw new Exception("الرجاء تدقيق تواريخ الاستلام والتسليم");
            else if (raddtpIssueDate.SelectedDate > raddtpDeliveryDate.SelectedDate)
                throw new Exception("تاريخ التسليم لايمكن أن يكون سابقا لتاريخ الاستلام");
            else if (rntxtSurveyNo.Value == null)
                throw new Exception(Feedback.NoSurveyNum(Session["lang"].ToString()));


            JobType type = ((radSection.Checked) ? JobType.Section : (radIntersection.Checked ? JobType.Intersection : (radRegionSecondary.Checked ? JobType.RegionSecondaryStreets : JobType.None)));
            string elementID = ((radSection.Checked) ? ddlMainStreetSection.SelectedValue : (radIntersection.Checked ? ddlMainStreetIntersection.SelectedValue : (radRegionSecondary.Checked ? ddlRegions.SelectedValue : "")));

            // int.Parse(hID.Value) , ddlSurveyor.SelectedItem.Text,  ((DateTime)  .ToString("dd/MM/yyyy")
            bool saved = new SurveyorSubmitJob().Insert(int.Parse(ddlSurveyor.SelectedValue), raddtpIssueDate.SelectedDate, raddtpDeliveryDate.SelectedDate,
                int.Parse(rntxtSurveyNo.Text), txtNotes.Text, elementID, type);

            if (saved)
            {
                btnCancel_Click(sender, e);
                lblFeedback.Text = Feedback.InsertSuccessfull(Session["lang"].ToString());
                gvSurveyorJob.DataBind();
            }
            else
                lblFeedback.Text = Feedback.InsertException(Session["lang"].ToString());

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ddlSurveyor.SelectedValue = "0";
        raddtpIssueDate.SelectedDate = null;
        raddtpDeliveryDate.SelectedDate = null;

        txtNotes.Text = "";
        lblFeedback.Text = "";
        //hID.Value = "";
        rntxtSurveyNo.Text = "1";
    }

    protected void odsSurveySubmitJobs_Deleted(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.DeleteSuccessfull(Session["lang"].ToString());
    }

    protected void odsSurveySubmitJobs_Updated(object sender, ObjectDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            lblFeedback.Text = e.Exception.InnerException.Message;
            e.ExceptionHandled = true;
        }
        else
            lblFeedback.Text = Feedback.UpdateSuccessfull(Session["lang"].ToString());
    }

    protected void lbtnSearch_Click(object sender, EventArgs e)
    {
        if (radSection.Checked)
        {
            if (ddlMainStreets.SelectedValue != "0")
            {
                Session["MainStreetID"] = ddlMainStreets.SelectedValue;
                SearchSection1.Visible = true;
            }
            else
                SearchSection1.Visible = false;
        }
        else if (radIntersection.Checked)
        {
            if (ddlMainStreets.SelectedValue != "0")
            {
                Session["MainStreetID"] = ddlMainStreets.SelectedValue;
                SearchIntersect1.Visible = true;
            }
            else
                SearchIntersect1.Visible = false;
        }
        else if (radRegionSecondary.Checked)
        {
            SearchRegion1.Visible = true;
        }
    }

    protected void onIntersectSearchChanged()
    {
        try
        {
            int selectedID = SearchIntersect1.SelectedIntersectionID;
            if (selectedID != 0)
            {
                ddlMainStreetIntersection.SelectedValue = selectedID.ToString();
                ddlMainStreetIntersection_SelectedIndexChanged(new Object(), new EventArgs());
                SearchIntersect1.Visible = false;
            }
            else
            {
                SearchIntersect1.Visible = false;
                ddlMainStreetIntersection.SelectedValue = "0";
                ddlMainStreetIntersection_SelectedIndexChanged(new Object(), new EventArgs());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void onSectionSearchChanged()
    {
        try
        {
            int selectedID = SearchSection1.SelectedSectionID;
            if (selectedID != 0)
            {
                ddlMainStreetSection.SelectedValue = selectedID.ToString();
                ddlMainStreetSection_SelectedIndexChanged(new Object(), new EventArgs());
                SearchSection1.Visible = false;
            }
            else
            {
                SearchSection1.Visible = false;
                ddlMainStreetSection.SelectedValue = "0";
                ddlMainStreetSection_SelectedIndexChanged(new Object(), new EventArgs());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void OnSetSearchChanged()
    {
        try
        {
            int selectedID = SearchRegion1.SelectedRegionID;
            if (selectedID != 0)
            {
                ddlRegions.SelectedValue = selectedID.ToString();
                ddlRegions_SelectedIndexChanged(new Object(), new EventArgs());
                SearchRegion1.Visible = false;
            }
            else
            {
                SearchRegion1.Visible = false;
                ddlRegions.SelectedValue = "0";
                ddlRegions_SelectedIndexChanged(new Object(), new EventArgs());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void lbtnSearchMainSt_Click(object sender, EventArgs e)
    {
        SearchMainSt1.Visible = true;
    }

    protected void onMainStSearchChanged()
    {
        try
        {
            int selectedID = SearchMainSt1.SelectedMainStreetID;
            if (selectedID != 0)
            {
                ddlMainStreets.SelectedValue = selectedID.ToString();
                ddlMainStreets_SelectedIndexChanged(new Object(), new EventArgs());
                SearchMainSt1.Visible = false;
            }
            else
            {
                SearchMainSt1.Visible = false;
                ddlMainStreets.SelectedValue = "0";
                ddlMainStreets_SelectedIndexChanged(new Object(), new EventArgs());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

}