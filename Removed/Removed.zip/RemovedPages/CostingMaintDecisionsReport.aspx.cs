﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL;

public partial class ASPX_Reports_CostingMaintDecisionsReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Permissions"] == null || Session["Permissions"].ToString()[7] != '1')
                Response.Redirect("~/ASPX/Default.aspx", false);

            radAll_CheckedChanged(sender, e);
        }
    }

    protected void radAll_CheckedChanged(object sender, EventArgs e)
    {
        ddlMaintDecision.Enabled = false;
        ddlContracts.Enabled = false;
    }

    protected void radByMaintDecision_CheckedChanged(object sender, EventArgs e)
    {
        ddlMaintDecision.Enabled = true;
        ddlContracts.Enabled = false;
    }

    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            if (radByMaintDecision.Checked && ddlMaintDecision.SelectedValue == "0")
                throw new Exception("الرجاء اختيار قرار صيانة");
            else if (radByContract.Checked && ddlContracts.SelectedValue == "0")
                throw new Exception("الرجاء اختيار عقد صيانة");
            else
            {
                DataTable dt = new MaintDecisionCosting().Search(radAll.Checked, int.Parse(ddlMaintDecision.SelectedValue), radByContract.Checked, int.Parse(ddlContracts.SelectedValue));
                if (dt.Rows.Count > 0)
                {
                    Session.Add("ReportData", dt);
                    string url = "ViewCostingMaintDecisionsReport.aspx";
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);
                }
                else
                    lblFeedback.Text = Feedback.NoData(Session["lang"].ToString());
            }

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        ddlContracts.SelectedValue = "0";
        ddlMaintDecision.SelectedValue = "0";

        radByMaintDecision.Checked = false;
        radAll.Checked = true;
        radAll_CheckedChanged(sender, e);
    }

    protected void radByContract_CheckedChanged(object sender, EventArgs e)
    {
        ddlMaintDecision.Enabled = false;
        ddlContracts.Enabled = true;
    }

}
