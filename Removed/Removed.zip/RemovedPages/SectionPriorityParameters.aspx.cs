﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL;

public partial class ASPX_Sections_SectionPriorityParameters : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[4] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            string select = Session["lang"].ToString().Contains("ar") ? "اختيار" : "select";

            pnlParams.Visible = false;

            ddlMainStreetSection.Items.Clear();
            ddlMainStreetSection.Items.Add(new ListItem(select, "0"));
            ddlMainStreetSection.DataBind();
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreetSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            DataTable dt = new MainStreetSection().GetSectionPriorityParameters(int.Parse(ddlMainStreetSection.SelectedValue));
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                ddlPopFactor.SelectedValue = dr["POP_FACTOR"].ToString();
                ddlTourismFactor.SelectedValue = dr["TOURISM_FACTOR"].ToString();
                ddlEntranceFactor.SelectedValue = dr["ENTRANCE"].ToString();
                ddlTrafficFactor.SelectedValue = dr["TRAFFIC_FACTOR"].ToString();
                ddlCompleteFactor.SelectedValue = dr["COMPLETE_FACTOR"].ToString();

                pnlParams.Visible = true;
            }
            else
            {
                pnlParams.Visible = false;
                lblFeedback.Text = Feedback.NoData(Session["lang"].ToString());
            }
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            bool saved = new MainStreetSection().UpdatePriorityParamters(int.Parse(ddlPopFactor.SelectedValue), int.Parse(ddlTourismFactor.SelectedValue),
                int.Parse(ddlEntranceFactor.SelectedValue), int.Parse(ddlTrafficFactor.SelectedValue), int.Parse(ddlCompleteFactor.SelectedValue),
                int.Parse(ddlMainStreetSection.SelectedValue));

            lblFeedback.Text = saved ? Feedback.InsertSuccessfull(Session["lang"].ToString()) : Feedback.InsertException(Session["lang"].ToString());
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblFeedback.Text = "";
        pnlParams.Visible = false;
        ddlMainStreetSection_SelectedIndexChanged(sender, e);
    }

}