﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL.UDI;
using System.Threading;
using System.Data;
using JpmmsClasses;

public partial class ASPX_Regions_RegionsUDI : System.Web.UI.Page
{

    protected Guid RequestID;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Permissions"] == null || Session["Permissions"].ToString()[2] != '1')
                Response.Redirect("~/ASPX/Default.aspx", false);

            radRegion_CheckedChanged(sender, e);
        }
    }

    private void CalculateUDI()
    {
        bool result = false;

        RegionSecondaryStUDI udi = new RegionSecondaryStUDI();
        int regionID = int.Parse(ddlRegions.SelectedValue);
        int survey = int.Parse(radlOldSurveys.SelectedValue.ToString());
        string user = Session["UserName"].ToString();

        //btnCalc.Enabled = false;
        if (radRegion.Checked)
            result = udi.CalculateRegionSecondaryStreetsUDI(regionID, survey, user);
        else if (raddistrict.Checked)
            result = udi.CalculateRegionSecondaryStreetsUDI(ddlDistricts.SelectedValue, survey, user);
        else if (radByRegionsAreaName.Checked)
            result = udi.CalculateRegionSecondaryStreetsUDI_ByDistrict(ddlDistrictNames.SelectedValue, survey, user);
        else if (radbyMunicName.Checked)
            result = udi.CalculateRegionSecondaryStreetsUDI_ByMunicipality(ddlMunic.SelectedValue, survey, user);

        if (result)
        {
            lblFeedback.Text = "تم الحساب بنجاح";

            DataTable dt = new DataTable();
            if (radRegion.Checked)
                dt = udi.GetSecondaryStreetsUdiByRegion(regionID, survey);
            else if (raddistrict.Checked)
                dt = udi.GetSecondaryStreetsUdiByRegion(ddlDistricts.SelectedValue, survey);
            else if (radByRegionsAreaName.Checked)
                dt = udi.GetSecondaryStreetsUdiByDistrict(ddlDistrictNames.SelectedValue, survey);
            else if (radbyMunicName.Checked)
                dt = udi.GetSecondaryStreetsUdiByMuniciplaity(ddlMunic.SelectedValue, survey);

            gvSecondaryUDI.DataSource = dt;
            gvSecondaryUDI.DataBind();

            ThreadResults.Add(RequestID, dt);
        }
        else
        {
            lblFeedback.Text = "فشلت عملية الحساب";
            gvSecondaryUDI.DataSource = null;
            gvSecondaryUDI.DataBind();
        }
    }


    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());


            if (radRegion.Checked && ddlRegions.SelectedValue == "0")
                throw new Exception("الرجاء اختيار المنطقة الفرعية");
            else if (raddistrict.Checked && ddlDistrictNames.SelectedValue == "0")
                throw new Exception("الرجاء اختيار الحي الفرعي");
            else if (radByRegionsAreaName.Checked && ddlDistrictNames.SelectedValue == "0")
                throw new Exception("الرجاء اختيار منطقة الأحياء الفرعية");
            else if (radbyMunicName.Checked && ddlMunic.SelectedValue == "0")
                throw new Exception("الرجاء اختيار البلدية الفرعية");
            else if (radlOldSurveys.SelectedIndex < 0)
                throw new Exception("الرجاء اختيار رقم المسح");

            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(CalculateUDI);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("result.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);
            //Response.Redirect(url, false);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
        finally
        {
            btnCalc.Enabled = true;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            gvSecondaryUDI.DataSource = null;
            gvSecondaryUDI.DataBind();

            radRegion.Checked = true;
            raddistrict.Checked = false;
            radByRegionsAreaName.Checked = false;
            radbyMunicName.Checked = false;
            radRegion_CheckedChanged(sender, e);

            ddlDistrictNames.SelectedValue = "0";
            ddlMunic.SelectedValue = "0";
            ddlDistricts.SelectedValue = "0";
            ddlRegions.SelectedValue = "0";
            ddlRegions_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radRegion_CheckedChanged(object sender, EventArgs e)
    {
        ddlRegions.Enabled = true;
        ddlDistricts.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = false;
    }

    protected void raddistrict_CheckedChanged(object sender, EventArgs e)
    {
        ddlDistricts.Enabled = true;
        ddlRegions.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = false;
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            gvSecondaryUDI.DataSource = null;
            gvSecondaryUDI.DataBind();

            radlOldSurveys.DataBind();
            //if (radlOldSurveys.Items.Count == 1)
            radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void ddlDistricts_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void radByRegionsAreaName_CheckedChanged(object sender, EventArgs e)
    {
        ddlDistricts.Enabled = false;
        ddlRegions.Enabled = false;
        ddlDistrictNames.Enabled = true;
        ddlMunic.Enabled = false;
    }

    protected void radbyMunicName_CheckedChanged(object sender, EventArgs e)
    {
        ddlDistricts.Enabled = false;
        ddlRegions.Enabled = false;
        ddlDistrictNames.Enabled = false;
        ddlMunic.Enabled = true;
    }

    protected void ddlDistrictNames_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void ddlMunic_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlRegions_SelectedIndexChanged(sender, e);
    }

}