﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;
using System.Threading;
using System.Data;
using JpmmsClasses;

public partial class ASPX_Intersections_IntersectsMaintenaceDecisions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[3] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            radlOldSurveys.DataBind();

            gvIntersectMaintDecisions.DataSource = null;
            gvIntersectMaintDecisions.DataBind();

            if (radlOldSurveys.Items.Count == 0)
                radlOldSurveys.SelectedIndex = -1;
            else
                radlOldSurveys.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }


    protected Guid RequestID;

    private void Calculate()
    {
        MaintenanceDecisions md = new MaintenanceDecisions();
        int mainStID = int.Parse(ddlMainStreets.SelectedValue);
        int survey = int.Parse(radlOldSurveys.SelectedValue.ToString());
        string user = Session["UserName"].ToString();

        bool result = md.PrepareMainStreetIntersectionsMaintenanceDecisions(mainStID, survey, user);
        if (result)
        {
            lblFeedback.Text = "تم الحساب بنجاح";
            DataTable dt = md.GetMainStreetIntersectionsMaintenanceDecisions(mainStID, survey);
            gvIntersectMaintDecisions.DataSource = dt;
            gvIntersectMaintDecisions.DataBind();

            ThreadResults.Add(RequestID, dt);
        }
        else
        {
            ThreadResults.Remove(RequestID);
            ThreadResults.message = "لم يتم حساب قرارات الصيانة لعدم توفر بيانات الوعورة أو السماكة لتقاطعات هذا الطريق";

            //lblFeedback.Text = "لم يتم حساب قرارات الصيانة لعدم توفر بيانات الوعورة أو السماكة لتقاطعات هذا الطريق"; //"فشلت عملية الحساب";
            gvIntersectMaintDecisions.DataSource = null;
            gvIntersectMaintDecisions.DataBind();
        }
    }

    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());


            if (ddlMainStreets.SelectedValue == "0")
                throw new Exception(Feedback.NoMainStreetSelected("ar"));
            else if (radlOldSurveys.SelectedIndex == -1)
                throw new Exception(Feedback.NoSurveyDateNum("ar"));


            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(Calculate);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("MdResults.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);

        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";
            gvIntersectMaintDecisions.DataSource = null;
            gvIntersectMaintDecisions.DataBind();

            ddlMainStreets.SelectedValue = "0";
            ddlMainStreets_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

}
