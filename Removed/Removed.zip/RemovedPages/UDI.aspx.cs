﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;
using JpmmsClasses.BL;
using System.Threading;
using JpmmsClasses;

public partial class ASPX_Operations_UDI : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[8] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        radlOldSurveys.SelectedIndex = 0;
        chkIntersections.Checked = false;
        chkRegions.Checked = false;
        chkSections.Checked = false;

        lblFeedback.Text = "";
    }

    protected Guid RequestID;


    private void Calculate()
    {
        DataTable dt;
        int survey = int.Parse(radlOldSurveys.SelectedValue);
        string user = Session["UserName"].ToString();

        MaintenanceDecisions md = new MaintenanceDecisions();

        if (chkRegions.Checked)
        {
            dt = new Region().GetSurveyedRegions();
            foreach (DataRow dr in dt.Rows)
                md.PrepareRegionSecondaryStreetsMaintenanceDecisions(int.Parse(dr["REGION_ID"].ToString()), survey, user);
        }

        if (chkIntersections.Checked)
        {
            dt = new MainStreet().GetMainStreetsHavingIntersectionsSurveyDistresses();
            foreach (DataRow dr in dt.Rows)
                md.PrepareMainStreetIntersectionsMaintenanceDecisions(int.Parse(dr["id3"].ToString()), survey, user);
        }

        if (chkSections.Checked)
        {
            dt = new MainStreet().GetMainStreetsHavingSurveyDistresses();
            foreach (DataRow dr in dt.Rows)
                md.PrepareMainStreetSectionsMaintenanceDecisions(int.Parse(dr["id3"].ToString()), survey, user);
        }


        dt = new DataTable();
        ThreadResults.Add(RequestID, dt);
    }


    protected void btnCalc_Click(object sender, EventArgs e)
    {
        try
        {
            lblFeedback.Text = "";

            if (!bool.Parse(Session["canEdit"].ToString()))
                throw new Exception(Feedback.NoPermissions());

            RequestID = Guid.NewGuid();
            ThreadStart ts = new ThreadStart(Calculate);
            Thread worker = new Thread(ts);
            worker.Start();

            string url = string.Format("ResultUDI.aspx?id={0}", RequestID.ToString());
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "RedirectScriptCoupon", "window.open('" + url + "', '_blank')", true);

            lblFeedback.Text = "تم الحساب بنجاح";
        }
        catch (Exception ex)
        {
            lblFeedback.Text = ex.Message;
        }
    }

    protected void radlOldSurveys_DataBound(object sender, EventArgs e)
    {
        if (radlOldSurveys.Items.Count > 0)
            radlOldSurveys.SelectedIndex = 0;
    }

}
