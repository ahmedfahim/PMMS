﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using JpmmsClasses.BL;
using JpmmsClasses.BL.Lookups;
using JpmmsClasses.BL.UDI;

public partial class ASPX_Operations_Feedbacks_AddFeedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Permissions"] == null || Session["Permissions"].ToString()[8] != '1')
            Response.Redirect("~/ASPX/Default.aspx", false);

        if (!IsPostBack)
        {
            radSection_CheckedChanged(sender, e);
            rdtpFinishDate.SelectedDate = DateTime.Today;
        }
    }

    protected void radSection_CheckedChanged(object sender, EventArgs e)
    {
        lblAddFeedback.Text = "";

        pnlMainSt.Visible = (radSection.Checked || radIntersect.Checked);
        ddlMainStreetSection.Visible = radSection.Checked;
        ddlMainStreetIntersection.Visible = radIntersect.Checked;

        ddlRegions.Enabled = radRegion.Checked;
        ddlRegionSecondaryStreets.Enabled = radRegion.Checked;

        ddlMainStreets.SelectedValue = "0";
        ddlMainStreets_SelectedIndexChanged(sender, e);

        ddlMainStreetSection.SelectedValue = "0";
        ddlMainStreetSection_SelectedIndexChanged(sender, e);

        ddlMainStreetIntersection.SelectedValue = "0";
        ddlMainStreetIntersection_SelectedIndexChanged(sender, e);

        ddlRegions.SelectedValue = "0";
        ddlRegions_SelectedIndexChanged(sender, e);
    }

    protected void radIntersect_CheckedChanged(object sender, EventArgs e)
    {
        radSection_CheckedChanged(sender, e);
    }

    protected void radRegion_CheckedChanged(object sender, EventArgs e)
    {
        radSection_CheckedChanged(sender, e);
    }

    protected void ddlMainStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";
            if (radSection.Checked)
            {
                ddlMainStreetSection.Items.Clear();
                ddlMainStreetSection.Items.Add(new ListItem("اختيار", "0"));
                ddlMainStreetSection.DataBind();
                ddlMainStreetSection.SelectedValue = "0";
                ddlMainStreetSection_SelectedIndexChanged(sender, e);
            }
            else if (radIntersect.Checked)
            {
                ddlMainStreetIntersection.Items.Clear();
                ddlMainStreetIntersection.Items.Add(new ListItem("اختيار", "0"));
                ddlMainStreetIntersection.DataBind();
                ddlMainStreetIntersection.SelectedValue = "0";
                ddlMainStreetIntersection_SelectedIndexChanged(sender, e);
            }

            ddlMainStreetSection_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreetSection_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";

            ddlSamples.Items.Clear();
            ddlSamples.Items.Add(new ListItem("اختيار", "0"));
            ddlSamples.DataBind();

            decimal? udi = UdiShared.GetRoadNetworkItemUdi(ddlMainStreetSection.SelectedValue, ddlMainStreetIntersection.SelectedValue, ddlSamples.SelectedValue,
                   ddlRegions.SelectedValue, ddlRegionSecondaryStreets.SelectedValue);

            lblUdiBefore.Text = (udi == null) ? "" : udi.ToString();
            ddlMaintDecisions_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void ddlMainStreetIntersection_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlMainStreetSection_SelectedIndexChanged(sender, e);
    }

    protected void ddlRegions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlRegionSecondaryStreets.Items.Clear();
            ddlRegionSecondaryStreets.Items.Add(new ListItem("اختيار", "0"));
            ddlRegionSecondaryStreets.DataBind();
            ddlRegionSecondaryStreets.SelectedValue = "0";
            ddlRegionSecondaryStreets_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void ddlRegionSecondaryStreets_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";

            decimal? udi = UdiShared.GetRoadNetworkItemUdi(ddlMainStreetSection.SelectedValue, ddlMainStreetIntersection.SelectedValue, ddlSamples.SelectedValue,
                   ddlRegions.SelectedValue, ddlRegionSecondaryStreets.SelectedValue);

            lblUdiBefore.Text = (udi == null) ? "" : udi.ToString();
            ddlMaintDecisions_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void ddlMaintDecisions_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int? udiAfter = new MaintDecision().GetMaintDecisionNewUDI(int.Parse(ddlMaintDecisions.SelectedValue), lblUdiBefore.Text);
            lblUdiAfter.Text = (udiAfter == null) ? "" : udiAfter.ToString();
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text=ex.Message;
        }
    }


    private bool ValidateData()
    {
        if (radSection.Checked && (string.IsNullOrEmpty(ddlMainStreetSection.SelectedValue) || ddlMainStreetSection.SelectedValue == "0"))
            throw new Exception(Feedback.NoSectionSelected());
        else if (radIntersect.Checked && (string.IsNullOrEmpty(ddlMainStreetIntersection.SelectedValue) || ddlMainStreetIntersection.SelectedValue == "0"))
            throw new Exception(Feedback.NoIntersectionSelected());
        else if (radRegion.Checked && (string.IsNullOrEmpty(ddlRegions.SelectedValue) || ddlRegions.SelectedValue == "0"))
            throw new Exception(Feedback.NoRegionSelected());
        else if (radRegion.Checked && (string.IsNullOrEmpty(ddlRegionSecondaryStreets.SelectedValue) || ddlRegionSecondaryStreets.SelectedValue == "0"))
            throw new Exception(Feedback.NoSecondaryStreetSelected());
        else if (ddlMaintDecisions.SelectedValue == "0")
            throw new Exception("الرجاء اختيار قرار الصيانة");
        else if (ddlContractors.SelectedValue == "0")
            throw new Exception("الرجاء اختيار المقاول");
        else if (rdtpFinishDate.SelectedDate == null)
            throw new Exception(Feedback.NoDateSelected());
        else
            return true;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";

            if (!ValidateData())
                return;


            bool saved = new MaintenanceFeedback().Insert(radSection.Checked, radIntersect.Checked, radRegion.Checked, ddlMainStreets.SelectedValue,
                ddlMainStreetSection.SelectedValue, ddlMainStreetIntersection.SelectedValue, ddlSamples.SelectedValue, ddlRegions.SelectedValue,
                ddlRegionSecondaryStreets.SelectedValue, int.Parse(ddlMaintDecisions.SelectedValue), ((DateTime)rdtpFinishDate.SelectedDate).ToString("dd/MM/yyyy"),
                lblUdiBefore.Text, int.Parse(lblUdiAfter.Text), int.Parse(ddlContractors.SelectedValue));

            if (saved)
            {
                lblAddFeedback.Text = Feedback.InsertSuccessfull();
                gvFeedbacks.DataBind();
            }
            else
                lblAddFeedback.Text = Feedback.InsertException();
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

    protected void btnCancelContract_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddFeedback.aspx", false);
    }

    protected void ddlSamples_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblAddFeedback.Text = "";

            decimal? udi = UdiShared.GetRoadNetworkItemUdi(ddlMainStreetSection.SelectedValue, ddlMainStreetIntersection.SelectedValue, ddlSamples.SelectedValue,
                 ddlRegions.SelectedValue, ddlRegionSecondaryStreets.SelectedValue);

            lblUdiBefore.Text = (udi == null) ? "" : udi.ToString();
            ddlMaintDecisions_SelectedIndexChanged(sender, e);
        }
        catch (Exception ex)
        {
            lblAddFeedback.Text = ex.Message;
        }
    }

}