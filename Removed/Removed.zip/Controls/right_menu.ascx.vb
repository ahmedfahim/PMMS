﻿

Partial Class Controls_right_menu
    Inherits System.Web.UI.UserControl

    
  

End Class
