﻿
Partial Class Controls_Path
    Inherits System.Web.UI.UserControl

End Class
